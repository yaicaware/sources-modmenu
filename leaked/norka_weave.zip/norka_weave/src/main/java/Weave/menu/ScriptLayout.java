package Weave.menu;
import Weave.Utils;
import android.content.Context;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import java.io.File;
import java.util.ArrayList;
import android.widget.Toast;
import android.view.ActionMode.Callback2;
import android.graphics.Color;

public class ScriptLayout extends LinearLayout {
	Context context;
	
	public ComponentBlock scriptBlock, buttonBlock, settingBlock;
	public LinearLayout leftlayout, rightlayout;
	
	public WeaveButton buttonLoad, buttonDelete, buttonRename;
	public WeaveTitle scriptSelected;
	
	public ImageView refresh;
	public ArrayList<ScriptItem> items = new ArrayList<>();
	
	public String currentName = "null",
				  currentPath = "/";
	public File currentFile;
	public int mainColor;
	
	public ArrayList<File> getScripts() {
		ArrayList<File> scripts = new ArrayList<>();
		File scriptDir = new File(Environment.getExternalStorageDirectory().toString() + "/LostClient/CFG");
		File[] scriptList = scriptDir.listFiles();
		if (scriptList != null) {
			for (File file: scriptList) {
				if (Utils.getFileExtension(file).equalsIgnoreCase("cfg") && file.getName().length() < 20) {
					scripts.add(file);
				}
			}
		}
		return scripts;
	}
	
	public void setConfigSelect(String nm) {
		scriptSelected.title.setText(nm);
	}
	
	public void select(int id) {
		for (ScriptItem item: items) {
			item.line.setBackgroundColor(Color.TRANSPARENT);
			item.title.setTextColor(Color.WHITE);
			item.isSelect = false;
		}
		items.get(id).line.setBackgroundColor(mainColor);
		items.get(id).title.setTextColor(mainColor);
		items.get(id).isSelect = true;
		
		currentName = items.get(id).name;
		currentFile = items.get(id).script;
		currentPath = items.get(id).script.toString();
		
		setConfigSelect(currentName);
		buttonBlock.title.setText(currentName);
		
		Utils.anim(items.get(id), 200);
	}
	
	public void updateList() {
		currentName = "null";
		currentFile = null;
		setConfigSelect(currentName);
		scriptBlock.main.removeAllViews();
		items.clear();
		
		int idx = 0;
		for (File sc: getScripts()) {
			final ScriptItem item = new ScriptItem(context, sc.getName(), sc);
			scriptBlock.main.addView(item);
			Utils.anim(item, 300);
			final int index = idx;
			item.setCallback(new ScriptItem.Callback() {
				public void onClick(String name, File file) {
					setConfigSelect(name);
					currentFile = file;
		
					currentPath = file.toString();
					select(index);
				}
			});
			items.add(item);
			idx++;
		}
	}
	
	public ScriptLayout(Context ctx) {
		super(ctx);
		context = ctx;
		
		mainColor = ColorList.colorOrange();
		
		setOrientation(LinearLayout.HORIZONTAL);
		{ // Main layout
			leftlayout = new LinearLayout(context);
			scriptBlock = new ComponentBlock(context, "Scripts list");
			scriptBlock.scrl.setFillViewport(true);
			scriptBlock.scrl.setLayoutParams(new LayoutParams(-1, -1, 1));
			
			leftlayout.addView(scriptBlock, new LayoutParams(-1, -1));
			// add left
			addView(leftlayout, new LayoutParams(-1, -1, 1));
			
			refresh = new ImageView(context);
			{
				refresh.setColorFilter(ColorList.colorGrayLight());
				refresh.setPadding(10,10,10,10);
				Utils.SetAssets(context, refresh, "refresh.png");
				scriptBlock.header.addView(refresh, Utils.dp(context, 20), Utils.dp(context, 20));
				
				refresh.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						updateList();
					}
				});
			}
			
			LinearLayout expand = new LinearLayout(context);
			// add center expand
			addView(expand, Utils.dp(context, 5), -1);
			
			rightlayout = new LinearLayout(context);
			{ // Buttons list and Settings script
				rightlayout.setOrientation(LinearLayout.VERTICAL);
				
				buttonBlock = new ComponentBlock(context, "Script name here");
				settingBlock = new ComponentBlock(context, "Actions");
				
				buttonBlock.scrl.setLayoutParams(new LayoutParams(-1, -1, 1));
				buttonBlock.scrl.setFillViewport(true);
				
				settingBlock.scrl.setLayoutParams(new LayoutParams(-1, -1, 1));
				settingBlock.scrl.setFillViewport(true);
				
				LinearLayout expand2 = new LinearLayout(context);
				
				// added
				rightlayout.addView(buttonBlock, new LayoutParams(-1, -1, 1));
				rightlayout.addView(expand2, -1, Utils.dp(context, 5));
				rightlayout.addView(settingBlock, new LayoutParams(-1, -1, 1));
			}
			addView(rightlayout, new LayoutParams(-1, -1, 1));
		}
		
		{ // Settings
			
			scriptSelected = new WeaveTitle(context, "null");
			settingBlock.main.addView(scriptSelected, -1, Utils.dp(context, 15));
			setConfigSelect(currentName);
			
			buttonLoad = new WeaveButton(context, "Load");
			settingBlock.main.addView(buttonLoad);
			buttonLoad.setCallback(new WeaveButton.Callback() {
				public void onClick() {
					if (currentFile != null) {
						WeaveTitle t = new WeaveTitle(context, Utils.readFromFile(context, currentFile));
						buttonBlock.main.addView(t);
						t.title.setLayoutParams(new LayoutParams(-2, -2));
					}
				}
			});
			
			buttonRename = new WeaveButton(context, "Rename");
			settingBlock.main.addView(buttonRename);
			
			buttonDelete = new WeaveButton(context, "Remove");
			settingBlock.main.addView(buttonDelete);
			
		}
	}
}
