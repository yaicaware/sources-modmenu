package Weave.menu;

import Weave.Utils;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup.LayoutParams;
import android.widget.Toast;

public class BottomLine {
	Context context;
	
	public LinearLayout mainlayout, line;
	public SwipeListener swipes;
	
	FrameLayout parentBox;
	
	public Callback callback;
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public static interface Callback {
		public void onSwipe();
	}
	
	public void addOnScreen() {
		parentBox = new FrameLayout(context);

		//parentBox.setOnTouchListener(handleMotionTouch);
		WindowManager wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0, 0,
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
		
		wmManager.addView(parentBox, wmParams);
		parentBox.addView(mainlayout);
	}
	
	public void swipe() {
		if (callback != null) {callback.onSwipe();}
	}
	
	public BottomLine(Context ctx) {
		context = ctx;
		
		swipes = new SwipeListener(context) {
			public void onSwipeUp() {
				swipe();
			}
		};
		
		mainlayout = new LinearLayout(context);
		{ // Main layout background
			mainlayout.setLayoutParams(new LayoutParams(Utils.dp(context, 200), Utils.dp(context, 20)));
			mainlayout.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
			
			line = new LinearLayout(context);
			{ // Line open design
				final GradientDrawable grad = new GradientDrawable();
				//grad.setColor(Color.argb(160, 0, 0, 0));
				grad.setCornerRadius(1000f);
				ValueAnimator colorAnim = ObjectAnimator.ofInt(Color.rgb(210, 0, 0), Color.rgb(210, 105, 0), Color.rgb(210, 210, 0), Color.rgb(105, 210, 0), Color.rgb(0, 210, 0), Color.rgb(0, 210, 105), Color.rgb(0, 210, 210), Color.rgb(0, 105, 210), Color.rgb(0, 0, 210), Color.rgb(105, 0, 210), Color.rgb(210, 0, 210), Color.rgb(210, 0, 105));

				colorAnim.setDuration(10000);
				colorAnim.setEvaluator(new ArgbEvaluator());
				colorAnim.setRepeatCount(ValueAnimator.INFINITE);
				colorAnim.setRepeatMode(ValueAnimator.RESTART);
				colorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
						@Override
						public void onAnimationUpdate(ValueAnimator animator) {
							grad.setColor((int) animator.getAnimatedValue());
						}
					});
				colorAnim.start();
				
				line.setBackgroundDrawable(grad);
				line.setElevation(15f);
				
				mainlayout.setPadding(5,0,5,20);
				mainlayout.addView(line, -1, Utils.dp(context, 5));
			}
		}
		
		mainlayout.setOnTouchListener(swipes);
		line.setOnTouchListener(swipes);
		addOnScreen();
	}
}
