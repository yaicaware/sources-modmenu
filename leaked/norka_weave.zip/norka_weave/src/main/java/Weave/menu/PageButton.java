package Weave.menu;

import Weave.Utils;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.annotation.NonNull;
import android.content.Context;
import android.graphics.Color;
import android.util.Property;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import android.net.http.X509TrustManagerExtensions;

public class PageButton extends LinearLayout {
	Context context;
	public LinearLayout pages, line;
	public ImageView icon, arrow;
	public TextView title;
	public int pageid = 0;
	public String path;
	
	public int mainColor = 0;
	public ArrayList<SectionButton> sects = new ArrayList<>();
	
	public boolean isOpen = false;
	
	public static interface onSectChange {
		public void open(int pid, int id);
	}
	
	public onSectChange callback;
	public onSectChange getCallback() {
		return callback;
	}
	public void setCallback(onSectChange call) {
		callback = call;
	}
	
	static class HeightProperty extends Property<View, Integer> {

        public HeightProperty() {
            super(Integer.class, "height");
        }

        @Override public Integer get(View view) {
            return view.getHeight();
        }

        @Override public void set(View view, Integer value) {
            view.getLayoutParams().height = value;
            view.setLayoutParams(view.getLayoutParams());
        }
    }
	
	private ObjectAnimator animateHeightTo(@NonNull View view, int height) {
        final int currentHeight = view.getHeight();
        ObjectAnimator animator = ObjectAnimator.ofInt(view, new HeightProperty(), 0, height);
        animator.setDuration(300);
        animator.setInterpolator(new DecelerateInterpolator());
		animator.addListener(new Animator.AnimatorListener() {
			@Override
			public void onAnimationStart(Animator animation) {}
			
			@Override
			public void onAnimationEnd(Animator animation) {
				view.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
			}
			
			@Override
			public void onAnimationCancel(Animator animation) {}
			
			@Override
			public void onAnimationRepeat(Animator animation) {}
		});
		return animator;
    }
	
	private ObjectAnimator animpage;
	private int height = 0;
	public void openPage(boolean isop) {
		if (!animpage.isRunning()) isOpen = isop;
		if (isOpen) {
			if (!animpage.isRunning()) {
				icon.setColorFilter(Color.WHITE);
				title.setTextColor(Color.WHITE);
				arrow.setColorFilter(Color.WHITE);
			
				arrow.setRotation(-90);
				pages.setVisibility(View.VISIBLE);
				
				pages.measure(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
				height = (int) (pages.getMeasuredHeight() * 1.55);
				animpage = animateHeightTo(pages, height);
				
				animpage.start();
			}
		} else {
			if (!animpage.isRunning()) {
				icon.setColorFilter(ColorList.colorGrayLight());
				title.setTextColor(ColorList.colorGrayLight());
				arrow.setColorFilter(ColorList.colorGrayLight());
			
				arrow.setRotation(90);
				
				animpage.cancel();
				pages.setLayoutParams(new LinearLayout.LayoutParams(-1, 0));
			}
		}
	}
	
	public PageButton(Context ctx, final String name, String path, final MainPanel panl, String[] sections, int pd) {
		super(ctx);
		context = ctx;
		pageid = pd;
		this.path = path;
		setOrientation(LinearLayout.VERTICAL);
		mainColor = ColorList.colorOrange();
		
		line = new LinearLayout(context);
		{ // Header
			line.setOrientation(LinearLayout.HORIZONTAL);
			line.setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 30)));
			icon = new ImageView(context);
			Utils.SetAssets(context, icon, path);
			icon.setPadding(15,15,15,15);
			icon.setColorFilter(ColorList.colorGrayLight());
			
			title = new TextView(context);
			title.setText(name);
			title.setTextSize(11.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(ColorList.colorGrayLight());
			title.setGravity(Gravity.CENTER_VERTICAL);
			
			arrow = new ImageView(context);
			Utils.SetAssets(context, arrow, "arrow.png");
			arrow.setPadding(25,25,25,25);
			arrow.setRotation(90);
			arrow.setColorFilter(ColorList.colorGrayLight());
			
			OnClickListener clck = new OnClickListener() {
				public void onClick(View v) {
					openPage(!isOpen);
				}
			};
			
			arrow.setOnClickListener(clck);
			icon.setOnClickListener(clck);
			title.setOnClickListener(clck);
			
			pages = new LinearLayout(context);
			pages.setOrientation(LinearLayout.VERTICAL);
			{ // pages layout
				pages.setVisibility(View.GONE);
				//pages.setMinimumHeight(Menu.dp(context, 80));
			}
			
			line.addView(icon, Menu.dp(context, 30), -1);
			line.addView(title, new LinearLayout.LayoutParams(-1, -1, 1));
			line.addView(arrow, Menu.dp(context, 30), -1);
		}
		
		{ // Sections
			for (int i = 0; i < sections.length; i++) {
				final SectionButton sect = new SectionButton(context, sections[i]);
				final int id = i;
				pages.addView(sect);
				sects.add(sect);
				sect.setClick(new OnClickListener() {
					public void onClick(View v) {
						ObjectAnimator animation = ObjectAnimator.ofFloat(sect.title, "alpha", 0, 1.0f);
						animation.setDuration(250);
						animation.start();
						callback.open(pageid, id);
					}
				});
			}
		}
		
		addView(line, -1, Menu.dp(context, 30));
		addView(pages, -1, -2);
		
		{ // Low line
			LinearLayout div = new LinearLayout(context);
			LinearLayout div2 = new LinearLayout(context);
			
			div.setPadding(3,0,3,0);
			div.setBackgroundColor(ColorList.colorGrayLight());
			
			div.addView(div2, -1, 1);
			addView(div, -1, -2);
		}
		
		animpage = animateHeightTo(pages, ((View) pages.getParent()).getHeight());
		openPage(false);
	}
}
