package Weave.menu;
import Weave.Utils;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainPanel extends LinearLayout {
	Context context;
	public LinearLayout main, header, line, page;
	public ScrollView scroll;
	
	public ImageView pageIcon, arrow, close;
	public TextView pagename, sectionname;

	public Menu menuinstance;
	
	private float corner = 10;
	
	public void setHead(String pagen, String sectn, String path) {
		pagename.setText(pagen);
		sectionname.setText(sectn);
		Utils.SetAssets(context, pageIcon, path);
		ObjectAnimator animation = ObjectAnimator.ofFloat(pageIcon, "alpha", 0.4f, 1.0f);
		animation.setDuration(250);
		animation.start();
		ObjectAnimator animation2 = ObjectAnimator.ofFloat(pagename, "alpha", 0.4f, 1.0f);
		animation2.setDuration(250);
		animation2.start();
		ObjectAnimator animation3 = ObjectAnimator.ofFloat(sectionname, "alpha", 0.4f, 1.0f);
		ObjectAnimator animation4 = ObjectAnimator.ofFloat(arrow, "alpha", 0.4f, 1.0f);
		animation4.setDuration(250);
		animation4.start();
		animation3.setDuration(250);
		animation3.start();
	}
	
	ArrayList<ArrayList<LinearLayout>> pageList = new ArrayList<>();
	ArrayList<ComponentBlock> blocks = new ArrayList<>();
	
	public void showPage(int id, int sect) {
		for (int i = 0; i < pageList.size(); i++) {
			for (int i1 = 0; i1 < pageList.get(i).size(); i1++) {
				pageList.get(i).get(i1).setVisibility(View.GONE);
			}
		}
		pageList.get(id).get(sect).setVisibility(View.VISIBLE);
		
		ObjectAnimator animation = ObjectAnimator.ofFloat(pageList.get(id).get(sect), "alpha", 0, 1.0f);
		animation.setDuration(250);
		animation.start();
	}
	
	public LinearLayout getBlock(int id) {
		return blocks.get(id).main;
	}
	
	public int newBlock(int pageid, int sectid, String[] names) {
		final int blockid = blocks.size();
		
		LinearLayout blockline = new LinearLayout(context);
		blockline.setOrientation(LinearLayout.HORIZONTAL);
		
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			ComponentBlock block = new ComponentBlock(context, name);
			blocks.add(block);
			
			if (names.length > 1) {
				if ((i != 0)) {
					LinearLayout expand = new LinearLayout(context);
					blockline.addView(expand, Menu.dp(context, 5), -1);
				}
			}
			blockline.addView(block, new LinearLayout.LayoutParams(-1, -1, 1));
			
		}
		pageList.get(pageid).get(sectid).addView(blockline, -1, -2);
		
		return blockid;
	}
	
	public int newPage(int count) {
		final int pageId = pageList.size();
		ArrayList<LinearLayout> sectionList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			LinearLayout pg = new LinearLayout(context);
			pg.setOrientation(LinearLayout.VERTICAL);
			sectionList.add(pg);
			page.addView(pg, -1, -1);
		}
		pageList.add(sectionList);
		
		return pageId;
	}
	
	public MainPanel(Context ctx, Menu menuinstance2) {
		super(ctx);
		context = ctx;
		menuinstance = menuinstance2;
		
		setOrientation(LinearLayout.VERTICAL);
		GradientDrawable menu = new GradientDrawable();
		menu.setColor(ColorList.colorMain());
		menu.setCornerRadius(corner);
		setBackgroundDrawable(menu);
		
		header = new LinearLayout(context);
		header.setOrientation(LinearLayout.HORIZONTAL);
		{ // Head
			GradientDrawable head = new GradientDrawable();
			head.setCornerRadii(new float[] {corner, corner, corner, corner, 0, 0, 0, 0});
			head.setColor(ColorList.colorMain());
			header.setBackgroundDrawable(head);
			header.setGravity(Gravity.CENTER_VERTICAL);
			
			pageIcon = new ImageView(context);
			Utils.SetAssets(context, pageIcon, "testicon.png");
			Utils.SetAssets(context, pageIcon, "iconma.png");
			pageIcon.setPadding(10,10,10,10);
			
			pagename = new TextView(context);
			pagename.setText("Player");
			pagename.setTextSize(11.0f);
			pagename.setTypeface(Utils.font(context));
			pagename.setTextColor(ColorList.colorGrayLight());
			pagename.setGravity(Gravity.CENTER);
			
			arrow = new ImageView(context);
			Utils.SetAssets(context, arrow, "arrow.png");
			arrow.setPadding(10,10,10,10);
			
			sectionname = new TextView(context);
			sectionname.setText("Main");
			sectionname.setTextSize(11.5f);
			sectionname.setTypeface(Utils.font(context));
			sectionname.setTextColor(ColorList.colorOrange());
			sectionname.setGravity(Gravity.CENTER);
			
			LinearLayout expand = new LinearLayout(context);
			close = new ImageView(context);
			close.setPadding(20,20,20,20);
			
			header.addView(pageIcon, Menu.dp(context, 25), -1);
			header.addView(pagename, -2, -1);
			header.addView(arrow, Menu.dp(context, 15), -1);
			header.addView(sectionname, -2, -1);
			header.addView(expand, new LinearLayout.LayoutParams(-1, -1, 1));
			header.addView(close, Menu.dp(context, 25), -1);
		}

		line = new LinearLayout(context);
		{ // Line after header
			line.setBackgroundColor(ColorList.colorOrange());
		}
		
		main = new LinearLayout(context);
		{ // Page menu
			main.setPadding(15, 15, 15, 15);
		}
		
		page = new LinearLayout(context);
		{ // Page layout
			page.setOrientation(LinearLayout.VERTICAL);
			
			main.addView(page, -1, -1);
		}
		
		addView(header, -1, Menu.dp(context, 25));
		addView(line, -1, Menu.dp(context, 2));
		addView(main, new LinearLayout.LayoutParams(-1, -1, 1));
	}
	
	public void setOnClose(OnClickListener clck) {
		close.setOnClickListener(clck);
	}
}
