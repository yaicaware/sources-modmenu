package Weave.menu;

import Weave.Utils;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Environment;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.ColorFilter;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import java.util.ArrayList;
import android.os.Handler;
import java.io.File;
import android.widget.ImageView;
import android.widget.Toast.Callback;
import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;
import android.widget.Toast;

class ColorList {
	
	public static int colorMain () {
		return Color.parseColor("#101010");
	}
	
	public static int colorHeader () {
		return Color.parseColor("#1A1A1A");
	}
	
	public static int colorBody () {
		return Color.parseColor("#141414");
	}
	
	public static int colorGrayLight () {
		return Color.parseColor("#5C5C5C");
	}
	
	public static int colorOrange () {
		return Color.parseColor("#8826f5");
	}
	
        public static int colorRad() {
	return Color.parseColor("#ff0000");
    }
}

public class Menu {
	protected int WIDTH, HEIGHT;
    
	protected Context context;
	
	protected FrameLayout parentBox;
	public LinearLayout menulayout; 
	
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	public SecondPanel panelleft, secondpanel;
	public LinearLayout expandLine;
	public MainPanel panelright;
	
	public ScriptLayout ScriptLayout;
	
	protected ImageView Logo;
	
	public BottomLine lineOpen;
	public TextView lastSect;
	
	public boolean isShow = true;
	
	public ArrayList<Object> views = new ArrayList<>();

	
	public int menuColor = 0;
	public void setMenuColor(int c) {
		menuColor = c;
		panelright.line.setBackgroundColor(menuColor);
		panelright.sectionname.setTextColor(menuColor);
		panelleft.line.setBackgroundColor(menuColor);
		panelleft.Logo.setColorFilter(menuColor);
		/*Utils.SetAssets(context, secondpanel.Logo, "icon.png");
		secondpanel.header.addView(Logo, -1, -1);*/
		//secondpanel.Logo.setColorFilter(new BlendModeColorFilter(menuColor, BlendMode.SRC_ATOP));
		
	
		for (int i = 0; i < panelleft.pageList.size(); i++) {
			panelleft.pageList.get(i).mainColor = menuColor;
			if (lastSect != null) {
				lastSect.setTextColor(menuColor);
			}
		}
		
	
	
		
		for (Object view : views) {
			if (view instanceof WeaveCheckBox) {
				((WeaveCheckBox) view).colorMain = menuColor;
				if (((WeaveCheckBox) view).isChecked) ((WeaveCheckBox) view).setColor(menuColor);
			}
			if (view instanceof WeaveSeekBar) {
				WeaveSeekBar seek = ((WeaveSeekBar) view);
				GradientDrawable thumb = new GradientDrawable();
				thumb.setColor(menuColor);
				thumb.setSize(30, 30);
				thumb.setCornerRadius(100);
				thumb.setStroke(6, Color.WHITE);
				thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

				seek.slider.setThumb(thumb);

				seek.slider.getProgressDrawable().setColorFilter(menuColor, PorterDuff.Mode.MULTIPLY);
			}
			if (view instanceof WeaveSeekBarFloat) {
				WeaveSeekBarFloat seek = ((WeaveSeekBarFloat) view);
				GradientDrawable thumb = new GradientDrawable();
				thumb.setColor(menuColor);
				thumb.setSize(30, 30);
				thumb.setCornerRadius(100);
				thumb.setStroke(6, Color.WHITE);
				thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

				seek.slider.setThumb(thumb);

				seek.slider.getProgressDrawable().setColorFilter(menuColor, PorterDuff.Mode.MULTIPLY);
			}
			Context context;
		}
	}

	public ComponentBlock scriptBlock, buttonBlock, settingBlock;
	public LinearLayout leftlayout, rightlayout;

	public WeaveButton buttonLoad, buttonDelete, buttonRename;
	public WeaveTitle scriptSelected;

	public ImageView refresh;
	public ArrayList<ScriptItem> items = new ArrayList<>();

	public String currentName = "null",
	currentPath = "/";
	public File currentFile;
	public int mainColor;
	
	protected ImageView logoView;

	public ArrayList<File> getScripts() {
		ArrayList<File> scripts = new ArrayList<>();
		File scriptDir = new File(Environment.getExternalStorageDirectory().toString() + "/LostClient/CFG");
		File[] scriptList = scriptDir.listFiles();
		if (scriptList != null) {
			for (File file: scriptList) {
				if (Utils.getFileExtension(file).equalsIgnoreCase("cfg") && file.getName().length() < 20) {
					scripts.add(file);
				}
			}
		}
		return scripts;
	}

	public void setConfigSelect(String nm) {
		scriptSelected.title.setText(nm);
	}

	public void select(int id) {
		for (ScriptItem item: items) {
			item.line.setBackgroundColor(Color.TRANSPARENT);
			item.title.setTextColor(Color.WHITE);
			item.isSelect = false;
		}
		items.get(id).line.setBackgroundColor(mainColor);
		items.get(id).title.setTextColor(mainColor);
		items.get(id).isSelect = true;

		currentName = items.get(id).name;
		currentFile = items.get(id).script;
		currentPath = items.get(id).script.toString();

		setConfigSelect(currentName);
		buttonBlock.title.setText(currentName);

		Utils.anim(items.get(id), 200);
	}

	public void updateList() {
		currentName = "null";
		currentFile = null;
		setConfigSelect(currentName);
		scriptBlock.main.removeAllViews();
		items.clear();

		int idx = 0;
		for (File sc: getScripts()) {
			final ScriptItem item = new ScriptItem(context, sc.getName(), sc);
			scriptBlock.main.addView(item);
			Utils.anim(item, 300);
			final int index = idx;
			item.setCallback(new ScriptItem.Callback() {
					public void onClick(String name, File file) {
						setConfigSelect(name);
						currentFile = file;

						currentPath = file.toString();
						select(index);
					}
				});
			items.add(item);
			idx++;
		}
	}
        
    
	public void initSettings() {
		int misc = newPage("Misc", "testicon1.png", new String[] {"Settings"});

		{ // TEST
			int setting = newBox(misc, 0, new String[] {"Colors", "Menu"});

			newColor(setting, "Menu color", new WeaveColorPicker.Callback() {
					public void onPick(int c) {
						setMenuColor(c);
					}
				});

			newCheckBox(setting, "Rainbow menu", new WeaveCheckBox.Callback() {
					public void onChanged(boolean ch) {
						isRainbow = ch;
					}
				});

			WeaveTitle title = new WeaveTitle(context, "Menu scale");
			panelright.getBlock(setting+1).addView(title);

			newSliderFloat(setting+1, "Menu Scale X", 1.0f, 1.0f, new WeaveSeekBarFloat.Callback() {
					public void onChange(float scale) {
						if (scale >= 0.5) {
							menulayout.setScaleX(scale);
						}
					}
				});
			newSliderFloat(setting+1, "Menu Scale Y", 1.0f, 1.0f, new WeaveSeekBarFloat.Callback() {
					public void onChange(float scale) {
						if (scale >= 0.5) {
							menulayout.setScaleY(scale);
						}
					}
				});
		    WeaveTitle uitle = new WeaveTitle(context, "Слил TW1X TEAM");
		    panelright.getBlock(setting+1).addView(uitle);
		}
		{ // Script page
	    }
	}
	protected void init(Context context) {
		this.context = context;
		
		parentBox = new FrameLayout(context);

		//parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0, 0,
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}

	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	public static int dp(Context ctx, float dp) {
		float scale = ctx.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public int newPage(String name, String path, String[] sects) {
		final int pgid = panelright.newPage(sects.length);
		PageButton butt = panelleft.newPage(name, path, sects, pgid);
		butt.setCallback(new PageButton.onSectChange() {
			public void open(int pagid, int pageopen) {
				showPage(pagid, pageopen);
			}
		});
		return pgid;
	}
			
			
	public void showPage(int pageid, int sectid) {
		panelright.showPage(pageid, sectid);
		for (PageButton butt : panelleft.pageList) {
			for (SectionButton sect : butt.sects) {
				sect.title.setTextColor(ColorList.colorGrayLight());
			}
		}
		panelright.setHead(panelleft.pageList.get(pageid).title.getText().toString(), panelleft.pageList.get(pageid).sects.get(sectid).title.getText().toString(), panelleft.pageList.get(pageid).path);
		panelleft.pageList.get(pageid).sects.get(sectid).title.setTextColor(menuColor);
		lastSect = panelleft.pageList.get(pageid).sects.get(sectid).title;
	}
	
	public void newSpinner(int boxid, String[] texts, WeaveSpinner.Callback call) {
		WeaveSpinner spinner = new WeaveSpinner(context, texts);
		spinner.setCallback(call);
		panelright.getBlock(boxid).addView(spinner);
	}
	
	public void newCheckBox(int boxid, String text, WeaveCheckBox.Callback call) {
		WeaveCheckBox check = new WeaveCheckBox(context);
		check.setText(text);
		check.setCallback(call);
		check.colorMain = menuColor;
		
		views.add(check);
		panelright.getBlock(boxid).addView(check);
	}
	
	public int newBox(int pageid, int sect, String[] name) {
		return panelright.newBlock(pageid, sect, name);
	}
	
	public void newSlider(int boxid, String text, int max, int current, WeaveSeekBar.Callback call) {
		WeaveSeekBar slider = new WeaveSeekBar(context, text, max, current);
		slider.setCallback(call);
		slider.mainColor = menuColor;
		GradientDrawable thumb = new GradientDrawable();
		thumb.setColor(menuColor);
		thumb.setSize(30, 30);
		thumb.setCornerRadius(100);
		//thumb.setPadding(40, 40, 40, 40);
		thumb.setStroke(6, Color.WHITE);
		thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

		slider.slider.setThumb(thumb);

		slider.slider.getProgressDrawable().setColorFilter(menuColor, PorterDuff.Mode.MULTIPLY);
		
		
		views.add(slider);
		panelright.getBlock(boxid).addView(slider);
	}
	public void newSliderFloat(int boxid, String text, float max, float current, WeaveSeekBarFloat.Callback call) {
		WeaveSeekBarFloat slider = new WeaveSeekBarFloat(context, text, max, current);
		slider.setCallback(call);
		slider.mainColor = menuColor;
		GradientDrawable thumb = new GradientDrawable();
		thumb.setColor(menuColor);
		thumb.setSize(30, 30);
		thumb.setCornerRadius(100);
		//thumb.setPadding(40, 40, 40, 40);
		thumb.setStroke(6, Color.WHITE);
		thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

		slider.slider.setThumb(thumb);

		slider.slider.getProgressDrawable().setColorFilter(menuColor, PorterDuff.Mode.MULTIPLY);


		views.add(slider);
		panelright.getBlock(boxid).addView(slider);
	}
	
	public void newButton(int boxid, String text, WeaveButton.Callback call) {
		WeaveButton button = new WeaveButton(context, text);
		button.setCallback(call);
		
		views.add(button);
		panelright.getBlock(boxid).addView(button);
	}
	
	public void newInput(int boxid, String text, WeaveInput.Callback call) {
		WeaveInput button = new WeaveInput(context, text);
		button.setCallback(call);
		views.add(button);
		panelright.getBlock(boxid).addView(button);
	}
	
	public void newColor(int boxid, String text, WeaveColorPicker.Callback call) {
		WeaveColorPicker color = new WeaveColorPicker(context, text);
		color.setCallback(call);
		
		panelright.getBlock(boxid).addView(color);
	}
	
	public void newTitle(int boxid, String text) {
		WeaveTitle titlenew = new WeaveTitle(context, text);
		panelright.getBlock(boxid).addView(titlenew);
	}
	
	public boolean isRainbow = false;
	public void setRainbow() {
		ValueAnimator colorAnim = ObjectAnimator.ofInt(Color.rgb(210, 0, 0), Color.rgb(210, 105, 0), Color.rgb(210, 210, 0), Color.rgb(105, 210, 0), Color.rgb(0, 210, 0), Color.rgb(0, 210, 105), Color.rgb(0, 210, 210), Color.rgb(0, 105, 210), Color.rgb(0, 0, 210), Color.rgb(105, 0, 210), Color.rgb(210, 0, 210), Color.rgb(210, 0, 105));

		colorAnim.setDuration(10000);
		colorAnim.setEvaluator(new ArgbEvaluator());
		colorAnim.setRepeatCount(ValueAnimator.INFINITE);
		colorAnim.setRepeatMode(ValueAnimator.RESTART);
        colorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
			@Override
			public void onAnimationUpdate(ValueAnimator animator) {
				if (isRainbow) {
					setMenuColor((int) animator.getAnimatedValue());
				}
			}
		});
        colorAnim.start();
	}
	
	public void showMenu() {
		isShow = true;;
		parentBox.addView(menulayout, WIDTH, HEIGHT);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
			PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
			PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));
		scaleDown.setDuration(350);
		scaleDown.start();
	}
	
	public void hideMenu() {
		isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
			PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
			PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
			public void run() {
				parentBox.removeAllViews();
			}
		}, 350);
	}
	
	public Menu(final Context context) {
		init(context);

	   
		
		
		WIDTH = dpi(456);
		HEIGHT = dpi(300);
		
		menuColor = ColorList.colorOrange();
		menulayout = new LinearLayout(context);
		menulayout.setOrientation(LinearLayout.HORIZONTAL);
		
		panelleft = new SecondPanel(context, this);
		{ // Left Panel
			menulayout.addView(panelleft, dpi(130), -1);
		}
		
		expandLine = new LinearLayout(context);
		{ // Expand
			menulayout.addView(expandLine, dpi(6), -1);
		}
		
		panelright = new MainPanel(context, this);
		{ // Menu panel
			menulayout.addView(panelright, new LinearLayout.LayoutParams(-1, -1, 1));
			panelright.setOnClose(new OnClickListener() {
				public void onClick(View v) {
					
				}
			});
		}
		
		setRainbow();
		
		lineOpen = new BottomLine(context);
		lineOpen.setCallback(new BottomLine.Callback() {
			public void onSwipe() {
				if (isShow) {
					hideMenu();
				} else {
					showMenu();
				}
			}
		});
		
		wmManager.addView(parentBox, wmParams);
		
		parentBox.addView(menulayout, WIDTH, HEIGHT);
	}
	
	View.OnTouchListener handleMotionTouch = new View.OnTouchListener() {
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		@Override
		public boolean onTouch(View vw, MotionEvent ev) {
			switch (ev.getAction()) {
				case MotionEvent.ACTION_DOWN:
					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;
				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);
					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);
					wmManager.updateViewLayout(vw, wmParams);
					break;
				case MotionEvent.ACTION_UP:
					/*if (isIconVisible && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}*/
					break;
			}
			return true;
		}
	};
}
