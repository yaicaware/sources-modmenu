package Weave;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Utils {
	public static void SetAssets(Context ctx, ImageView img, String path) {
		try {
			InputStream ims = ctx.getAssets().open(path);
			Drawable d = Drawable.createFromStream(ims, null);
			img.setImageDrawable(d);
			ims .close();
		}
		catch(IOException ex) {return;}
	}
	
	public static Typeface font(Context ctx) {
		return Typeface.createFromAsset(ctx.getAssets(), "Font.ttf");
	}
	
	public static int dp(Context context, float dp)
	{
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public static void anim(View v, int time) {
		ObjectAnimator animation = ObjectAnimator.ofFloat(v, "alpha", 0, 1.0f);
		animation.setDuration(time);
		animation.start();
	}
	
	public static void disanim(View v, int time) {
		ObjectAnimator animation = ObjectAnimator.ofFloat(v, "alpha", 1.0f, 0);
		animation.setDuration(time);
		animation.start();
	}
	
	public static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        	return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
	
	public static void log(Context ctx, String t) {
		Toast.makeText(ctx, t, 1).show();
	}
	
	public static String readFromFile(Context contect, File myFile) {
		String aBuffer = "";
		try {
			FileInputStream fIn = new FileInputStream(myFile);
			BufferedReader myReader = new BufferedReader(new InputStreamReader(fIn));
			String aDataRow = "";
			while ((aDataRow = myReader.readLine()) != null) {
				aBuffer += aDataRow;
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return aBuffer;
	}
}
