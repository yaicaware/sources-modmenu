package Weave;

import android.animation.*;
import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import Weave.menu.*;
import android.view.View.*;
import Weave.*;
import java.util.prefs.BackingStoreException;

public class ActivityMain extends Activity  
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		Main.start(this);
		
	
    }
}
