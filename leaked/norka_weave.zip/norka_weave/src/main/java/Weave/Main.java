package Weave;

import Weave.menu.Menu;
import Weave.menu.WeaveButton;
import Weave.menu.WeaveCheckBox;
import Weave.menu.WeaveColorPicker;
import Weave.menu.WeaveInput;
import Weave.menu.WeaveSeekBar;
import Weave.menu.WeaveSeekBarFloat;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;
import Weave.menu.WeaveSpinner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.awt.*;
import java.io.*;
import android.os.Process;
import android.content.ClipboardManager;
import android.app.AlertDialog;
import android.animation.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.util.*;
import android.os.*;
import android.view.*;
import android.text.*;
import android.widget.*;
import android.app.AlertDialog;
import android.R;
import android.net.Uri;
import javax.security.auth.Destroyable;
import java.util.regex.MatchResult;
import android.transition.AutoTransition;
import java.io.UnsupportedEncodingException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.awt.*;
import java.io.*;
import android.os.Process;
import android.content.ClipboardManager;

public class Main {
	protected static Context context;
	
    private static native String[] getFeatures();
	public static native String getTitleName();
	public static native String getTiled();
	private static native String sex();
    private static native String title();
	public static native void Callback(int featureid, boolean check, int value, float value2, String valuestr, int red, int green, int blue);
	public static void start(final Context context) {
		Main.context = context;
		if (Build.VERSION.SDK_INT >= 23) {
			if (context.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
				|| context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				((Activity) context).requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
				init(context);
			}
			else {
				init(context);
			}
		}
		else {
			init(context);
		}
	}
	
	public Integer parseInt(String tok) {
		return Integer.parseInt(tok);
	}
	
    
	
    public static void init(final Context context)
	{
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
		System.loadLibrary("gvraudio");
	/*	String[] s94t = {
			"€",
			"#",
			"$",
			"*",
			"2",
			"&",
			"*",
			"@&",
			"'$",
			":*",
			"2:",
			"$7$7",
			":2/:3)+:$)-'$",
			"$_86$&86$_)6$&",
			"'#9-#'-9#:97$&97$&",
			"#-'8#-'#9-'#",
			"2'#-&#9+#&",
			"#79#&97#",
			"#&07#&97#",
			"#&9#7&",
			"€",
			"#",
			"$",
			"*",
			"2",
			"&",
			"*",
			"@&",
			"'$",
			":*",
			"2:",
			"$7$7",
			":2/:3)+:$)-'$",
			"$_86$&86$_)6$&",
			"'#9-#'-9#:97$&97$&",
			"#-'8#-'#9-'#",
			"2'#-&#9+#&",
			"#79#&97#",
			"#&07#&97#",
			"#&9#7&",
			"#)-&#)",
			"#)-&#)",
			"#'8-#'9-#&97#&",
		};
		String android_id = android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
		String getFingerprint = android.os.Build.FINGERPRINT;
		String getHardware = android.os.Build.HARDWARE;
		String[] s9t = {
			"€",
			"#",
			"$",
			"*",
			"2",
			"&",
			"*",
			"@&",
			"'$",
			":*",
			"2:",
			"$7$7",
			":2/:3)+:$)-'$",
			"$_86$&86$_)6$&",
			"'#9-#'-9#:97$&97$&",
			"#-'8#-'#9-'#",
			"2'#-&#9+#&",
			"#79#&97#",
			"#&07#&97#",
			"#&9#7&",
			"€",
			"#",
			"$",
			"*",
			"2",
			"&",
			"*",
			"@&",
			"'$",
			":*",
			"2:",
			"$7$7",
			":2/:3)+:$)-'$",
			"$_86$&86$_)6$&",
			"'#9-#'-9#:97$&97$&",
			"#-'8#-'#9-'#",
			"2'#-&#9+#&",
			"#79#&97#",
			"#&07#&97#",
			"#&9#7&",
			"#)-&#)",
			"#)-&#)",
			"#'8-#'9-#&97#&",
		};
		String getHost = android.os.Build.HOST;
		String result = "''|" + android_id + "|" + getFingerprint + "|" + getHardware + "|'',";
		if (urlRequest(title()).contains(result))
		{*/
			String[] st = {
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"#)-&#)",
				"#)-&#)",
				"#'8-#'9-#&97#&",
			};
			Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						String[] s94t = {
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"#)-&#)",
							"#)-&#)",
							"#'8-#'9-#&97#&",
						};
						new Main().CreateMenu(context);
					}
				}, 3000);
		/*} else {
			String[] s865t = {
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"#)-&#)",
				"#)-&#)",
				"#'8-#'9-#&97#&",
			};
			AlertDialog.Builder a = new AlertDialog.Builder(context);
			a.setCancelable(false);
			a.setTitle(sex().split("~")[0]);
			a.setMessage(sex().split("~")[1]);
			String[] s94086t = {
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"€",
				"#",
				"$",
				"*",
				"2",
				"&",
				"*",
				"@&",
				"'$",
				":*",
				"2:",
				"$7$7",
				":2/:3)+:$)-'$",
				"$_86$&86$_)6$&",
				"'#9-#'-9#:97$&97$&",
				"#-'8#-'#9-'#",
				"2'#-&#9+#&",
				"#79#&97#",
				"#&07#&97#",
				"#&9#7&",
				"#)-&#)",
				"#)-&#)",
				"#'8-#'9-#&97#&",
			};
			a.setNegativeButton((sex().split("~")[2]),
				new DialogInterface.OnClickListener()
				{
				    public void onClick(DialogInterface dialog, int id)
					{
						String[] s94o3t = {
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"#)-&#)",
							"#)-&#)",
							"#'8-#'9-#&97#&",
						};
						String android_id = android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
						String getFingerprint = android.os.Build.FINGERPRINT;
						String getHardware = android.os.Build.HARDWARE;
						String getHost = android.os.Build.HOST;
						String[] s948t = {
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"€",
							"#",
							"$",
							"*",
							"2",
							"&",
							"*",
							"@&",
							"'$",
							":*",
							"2:",
							"$7$7",
							":2/:3)+:$)-'$",
							"$_86$&86$_)6$&",
							"'#9-#'-9#:97$&97$&",
							"#-'8#-'#9-'#",
							"2'#-&#9+#&",
							"#79#&97#",
							"#&07#&97#",
							"#&9#7&",
							"#)-&#)",
							"#)-&#)",
							"#'8-#'9-#&97#&",
						};
						String result = "''|" + android_id + "|" + getFingerprint + "|" + getHardware + "|'',";
						ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
						clipboard.setText(result);
						Toast.makeText(context, sex().split("~")[5], 1).show();
						System.exit(Integer.parseInt(sex().split("~")[4]));
                    }
			    });
			a.setNeutralButton((sex().split("~")[3]),
				new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						System.exit(Integer.parseInt(sex().split("~")[4]));
					}
				});
			a.create().show();
		}*/
	}
	private static String urlRequest(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(str).openConnection().getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
                sb.append("\n");
            }
            bufferedReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    
	public final void CreateMenu(final Context context) {
		Main.context = context;
		
		final Menu menu = new Menu(context);
		final String[] features = getFeatures();
		
		for (final String feature: features) {
			final String[] split = feature.split("_");
			final String token = split[0];
			switch (token) {
				case "page":
					menu.newPage(split[1], split[2], split[3].split(","));
					break;
				case "block":
					menu.newBox(parseInt(split[1]), parseInt(split[2]), split[3].split(","));
					break;
				case "title":
					menu.newTitle(parseInt(split[1]), split[2]);
					break;
				case "checkbox":
					menu.newCheckBox(parseInt(split[1]), split[2], new WeaveCheckBox.Callback() {
						public void onChanged(boolean check) {
							Callback(parseInt(split[3]), check, 0, 0.0f, "", 0, 0, 0);
						}
					});
					break;
				case "button":
					menu.newButton(parseInt(split[1]), split[2], new WeaveButton.Callback() {
						public void onClick() {
							Callback(parseInt(split[3]), false, 0, 0.0f, "", 0, 0, 0);
						}
					});
					break;
				case "input":
					menu.newInput(parseInt(split[1]), split[2], new WeaveInput.Callback() {
						public void onPut(String t) {
							Callback(parseInt(split[3]), false, 0, 0.0f, t, 0, 0, 0);
						}
					});
					break;
				case "slider":
					menu.newSlider(parseInt(split[1]), split[2], parseInt(split[3]), parseInt(split[4]), new WeaveSeekBar.Callback () {
						public void onChange(int value) {
							Callback(parseInt(split[5]), false, value, 0.0f, "", 0, 0, 0);
						}
					});
					break;
				case "sliderfloat":
					menu.newSliderFloat(parseInt(split[1]), split[2], Float.parseFloat(split[3]), Float.parseFloat(split[4]), new WeaveSeekBarFloat.Callback () {
							public void onChange(float value) {
								Callback(parseInt(split[5]), false, 0, value, "", 0, 0, 0);
							}
						});
					break;
				case "color":
					menu.newColor(parseInt(split[1]), split[2], new WeaveColorPicker.Callback() {
						public void onPick(int c) {
							Callback(parseInt(split[3]), false, 0, 0, "", Color.red(c), Color.green(c), Color.blue(c));
						}
					});
					break;
				case "spinner":
					menu.newSpinner(parseInt(split[1]), split[2].split(","), new WeaveSpinner.Callback() {
						public void onPut(String t, int idx) {
							Callback(parseInt(split[3]), false, idx, 0.0f, t, 0, 0, 0);
						}
					});
					break;
			}
		}
		
		menu.initSettings();
		menu.showPage(0, 0);
	}
}

