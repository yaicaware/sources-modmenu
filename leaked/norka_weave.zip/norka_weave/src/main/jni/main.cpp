#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Includes/Logger.h>
#include <iostream>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include "menu.h"

extern "C" {
const char *libName = "libil2cpp.so";
struct My_Patches {MemoryPatch Noclip, MoveBT, BuyZone, Attach, NoSpawn;} hexPatches;



JNIEXPORT jstring  JNICALL Java_Weave_Main_getTitleName(JNIEnv *env, jobject activityObject) {
	return env->NewStringUTF("t.me/NeoFarelly");
}
JNIEXPORT jstring JNICALL
    Java_Weave_Main_sex(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("Вы не зарегистрированы в Чите!~За покупкой писать в Telegram : @mb_NeoFarelly\nЕсли вы уже приобрели чит, то скопируйте ID, и отправьте мне его в Telegram~Скопировать ID~Выйти~Скопировано");
        return str;
	}
	JNIEXPORT jstring JNICALL
    Java_Weave_Main_title(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("https://pastebin.com/raw/8D8YbEMq");
        return str;
    }

JNIEXPORT jobjectArray  JNICALL Java_Weave_Main_getFeatures(JNIEnv *env, jobject activityObject) {jobjectArray ret;
	const char *features[] = {
		
 "page_Visuals_testicon4.png_Chams,Esp,Other", // 0
 "page_Weapon_testicon.png_Weapon,Aim,Grenade & Bomb", // 1
 "page_Game_testicon3.png_Player,Movoment", // 2
 "page_Skins_testicon2.png_Skinchanger,Legit Skinchanger", // 3
  
  //****Player Weapon Skins*****
  "block_0_0_Chams,Settings", // 0, 1
  "block_0_1_Esp,Other", // 2, 3
  "block_0_2_World,View", // 4, 5
  
  // Visual - Chams - Chams
   "checkbox_0_Enable_0",
   "title_0_Mode_1",
   "spinner_0_None,Textured,Shading,Wireframe,Glow,Outline_3",
   
  // Visual - Chams - Settings
   "slider_1_Color red_255_0_4",
   "slider_1_Color green_255_0_5",
   "slider_1_Color blue_255_0_6",
   "title_1_Lines",
   "sliderfloat_1_Lines Width_15_0_8",
   "title_1_Styles",
   "checkbox_1_Transparent_10",
   "title_1_Color Modes",
   "checkbox_1_Rainbow_12",
   "sliderfloat_1_Rainbow Speed_20_0_13",
   "checkbox_1_Pulse_14",
   "sliderfloat_1_Pulse Speed_20_0_15",
   
  // Visual - Esp - Esp
   "checkbox_2_Enable_16",
   "checkbox_2_Preview_17",
   "title_2_Box Customization",
   "checkbox_2_Enable_18",
   "spinner_2_None,Gradient,Outline,Corner_19",
   "sliderfloat_2_Stroke_20_0_20",
   "sliderfloat_2_Round_20_0_21",
   "title_2_Counters",
   "checkbox_2_Tracer_22",
   "checkbox_2_Name_23",
   "checkbox_2_Health_24",
   "checkbox_2_Armor_25",
   "checkbox_2_Distance_26",
   "checkbox_2_Team_27",
   "checkbox_2_Circle (BUG)_28",
   
  // Visual - Esp - Other
   "checkbox_3_Watermark_29",
   "title_3_Crosshair",
   "slider_3_Size_200_0_30",
   
  
  // player - weapon - Game (0)******!!!
       /* "title_3_Player",
        "checkbox_3_Radar Hack_0",
        "checkbox_3_Money Hack_1",
        "checkbox_3_NoRecoil_2",
        "title_3_Test",
		"input_3_test_3",
		"sliderfloat_3_test2_255_0_4",
		"button_3_test3_5",
		"spinner_3_AK47,M4A4,AN94,M4A1,DEAGLE,AWP,SSCOUT,SV98,SSG08_20001",*/
	};
int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 

std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

void hexChange(bool &var, MemoryPatch &patch) {
	var = !var;
	if (var) {
		patch.Modify();
	} else {
		patch.Restore();
	}
}

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

std::string fto_string(float param) {
	std::string str = "";
	int num = (int) (param * 100);
	str = to_string(num);
	if (str.size() > 2) str.insert(str.size() - 2, ",");
	return str;
}

  
JNIEXPORT void JNICALL Java_Weave_Main_Callback(JNIEnv *env, jobject activityObject, jint feature, jboolean check, jint value, jfloat value2, jstring value3, jint red, jint green, jint blue) {
	std::string value_str = jstring2string(env, value3);
	switch (feature) {
	}
		
}

// ---------- Hooking ---------- //

void *hack_thread(void *) {
	
	ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
    // ---------- Hook ---------- //
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {
    }
}
