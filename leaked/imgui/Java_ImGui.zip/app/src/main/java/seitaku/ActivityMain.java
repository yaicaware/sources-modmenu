/* leak by t.me/yaicaware */

package seitaku;

import android.animation.*;
import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import seitaku.modmenu.*;

import seitaku.modmenu.Menu;
import android.view.View.*;
import seitaku.*;

public class ActivityMain extends Activity  
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		StaticActivity.Start(this);   
    }
}
