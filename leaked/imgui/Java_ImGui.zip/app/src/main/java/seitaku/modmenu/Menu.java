/* leak by t.me/yaicaware */

package seitaku.modmenu;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import seitaku.*;
import androtrainer.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.SearchView.OnCloseListener;
import android.view.View.OnClickListener;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import android.widget.SeekBar.OnSeekBarChangeListener;

class PageButton {
	public Context context;
	public String text = "Null";
	
	public boolean isOpen = false;
	
	public LinearLayout line, button;
	TextView title;
	
	public void setChecked(Boolean ch) {
		isOpen = ch;
		GradientDrawable grad = new GradientDrawable();
		grad.setCornerRadii(new float[] {5, 5, 5, 5, 0, 0, 0, 0});
		
		if (isOpen) {
			grad.setColor(Color.parseColor(Menu.colorPurpleButton));
		} else {
			grad.setColor(Color.parseColor(Menu.colorPurpleDark));
		}
		button.setBackgroundDrawable(grad);
	}
	
	public void setOnClick(final OnClickListener clck) {
		button.setOnClickListener(clck);
		title.setOnClickListener(clck);
	}
	
	public PageButton(Context ctx, String txt) {
		context = ctx;
		text = txt;
		
		line = new LinearLayout(context);
		line.setPadding(5, 8, 5, 0);
		
		button = new LinearLayout(context);
		GradientDrawable grad = new GradientDrawable();
		grad.setCornerRadii(new float[] {5, 5, 5, 5, 0, 0, 0, 0});
		grad.setColor(Color.parseColor(Menu.colorPurpleDark));
		button.setBackgroundDrawable(grad);
		button.setPadding(5,0,5,0);
		
		title = new TextView(context);
		title.setText(text);
		title.setTextColor(Color.WHITE);
		title.setTextSize(17f);
		title.setTypeface(Menu.font(context));
		title.setGravity(Gravity.CENTER);
		
		line.addView(button, -1, -1);
		button.addView(title, -1, -1);
		
		line.setLayoutParams(new LinearLayout.LayoutParams(-2, -1));
	}
}

class Switch {
	Context context;
	String text;
	public boolean isChecked = false;
	public LinearLayout line, check;
	public TextView title;
	
	public void setChecked(boolean chck) {
		isChecked = chck;
		GradientDrawable grad = new GradientDrawable();
		grad.setCornerRadius(5f);
		if (isChecked) {
			grad.setColor(Color.parseColor(Menu.colorPurpleButton));
		}
		grad.setStroke(2, Color.parseColor(Menu.colorPurpleDark));
		check.setBackgroundDrawable(grad);
	}
	
	public void setOnClick(final OnClickListener clck) {
		OnClickListener clck2 = new OnClickListener() {
			public void onClick(View v) {
				clck.onClick(v);
				setChecked(!isChecked);
			}
		};
		check.setOnClickListener(clck2);
		title.setOnClickListener(clck2);
	}
	
	public Switch(Context ctx, String txt, boolean chec) {
		context = ctx;
		text = txt;
		
		line = new LinearLayout(context);
		line.setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 24)));
		line.setOrientation(LinearLayout.HORIZONTAL);
		line.setPadding(5,5,5,5);
		
		check = new LinearLayout(context);
		title = new TextView(context);
		title.setText(text);
		title.setTextColor(Color.WHITE);
		title.setTextSize(14.5f);
		title.setTypeface(Menu.font(context));
		title.setGravity(Gravity.CENTER_VERTICAL);
		title.setPadding(5,0,0,0);
		
		line.addView(check, Menu.dp(context, 20), Menu.dp(context, 20));
		line.addView(title, -1, -1);
		
		setChecked(chec);
	}
}


class Slider {
	Context context;
	String text;
	int max, current;
	public SeekBar slider;
	public RelativeLayout line;
	public TextView title, title2;
	public LinearLayout lined;
	public int value;
	public Callback call;
	
	public void setValue(int v) {
		value = v;
		slider.setProgress(v);
		title.setText(Integer.toString(v));
	}
	
	public Slider(Context ctx, String txt, int maxv, int currentc, Callback cl) {
		
		context = ctx;
		text = txt;
		call = cl;
		max = maxv;
		current = currentc;
		
		line = new RelativeLayout(context);
		line.setLayoutParams(new RelativeLayout.LayoutParams(-1, Menu.dp(context, 40)));
		line.setPadding(5,5,5,5);
		line.setGravity(Gravity.CENTER);
		
		slider = new SeekBar(context);
		slider.setPadding(0,0,0,0);
		GradientDrawable thumb = new GradientDrawable();
		thumb.setColor(Color.parseColor(Menu.colorPurpleButton));
		thumb.setSize(40, 60);
		thumb.setCornerRadius(5);
		thumb.setPadding(20, 0, 20, 0);

		thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

		slider.setThumb(thumb);

		GradientDrawable btn = new GradientDrawable();
		btn.setColor(Color.parseColor(Menu.colorGraySlider));
		btn.setSize(1000, 8);
		slider.setPadding(5,0,5,0);
		
		slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			public void onProgressChanged(SeekBar s, int val, boolean c) {
				setValue(val);
				call.onChange(value);
			}
			
			public void onStopTrackingTouch(SeekBar b) {}
			
			public void onStartTrackingTouch(SeekBar b) {}
		});
		
		btn.setTintMode(PorterDuff.Mode.CLEAR);

		btn.setCornerRadius(3);
		
		slider.setProgressDrawable(btn);
		
		title = new TextView(context);
		title.setText(Integer.toString(current));
		title.setTextColor(Color.WHITE);
		title.setTextSize(12f);
		title.setTypeface(Menu.font(context));
		title.setGravity(Gravity.CENTER);
		
		title2 = new TextView(context);
		title2.setText(text);
		title2.setTextColor(Color.WHITE);
		title2.setTextSize(14f);
		title2.setTypeface(Menu.font(context));
		title2.setGravity(Gravity.CENTER_VERTICAL);
		
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
			-1, -1);
		params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
		
		line.addView(slider, params);
		
		RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(
			-1, -1);
		params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
		
		line.addView(title, params2);
		
		lined = new LinearLayout(context);
		lined.setOrientation(LinearLayout.HORIZONTAL);
		
		lined.addView(line, Menu.dp(context, 200), -1);
		lined.addView(title2, -1, -1);
		setValue(current);
		slider.setMax(max);
		
		lined.setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 20)));
		
	}
	
	public static interface Callback {
		public void onChange(int v);
	}
}

public class Menu
{
	
	public static String colorPurple = "#B600FF";
	public static String colorDark = "#0F0F0F";
	public static String colorGraySlider = "#1C1C1C";
	public static String colorPurpleButton = "#C500FF";
	public static String colorPurpleDark = "#71009F";
	
	protected int WIDTH,HEIGHT;
    
    public static Typeface font(Context ctx) {
		return Typeface.createFromAsset(ctx.getAssets(), "Font.ttf");
	}
	protected Context context;
	protected ImageView iconView,close;
	protected FrameLayout parentBox;
	protected LinearLayout menulayout, headerlayout, pageslayout, mainlayout, pagelayout;
	protected ScrollView scrollItems;    
	protected TextView title;
	
	public boolean isHide = false;
	
	public ArrayList<PageButton> pageButts = new ArrayList<>();
	public ArrayList<LinearLayout> pageList = new ArrayList<>();
	
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;

	public final void setImageFromAssets(ImageView image, String src) {
		try {
			InputStream ims = context.getAssets().open(src);
			Drawable d = Drawable.createFromStream(ims, null);
			image.setImageDrawable(d);
		} catch(IOException ex) {}
	}
	
	protected void init(Context context)
	{
		
		this.context = context;
		iconView = new ImageView(context);
		
		parentBox = new FrameLayout(context);

		parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		
		try {
		} catch (Exception e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			100,//initialX
			100,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_FULLSCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}

	public void setIconImage(String Icon)
	{
		
        byte[] decode = Base64.decode(Icon, 0);
        iconView.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
			iconView.setPadding(dpi(20), dpi(20), 0, 0);
        iconView.setImageAlpha(200);
	}
	
	public void setWidth(int px)
	{
		FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)menulayout.getLayoutParams();
		lp.width = px;
		menulayout.setLayoutParams(lp);
		WIDTH=px;
	}
	
	public void setHeight(int px)
	{
		FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)menulayout.getLayoutParams();
		lp.height = px;
		menulayout.setLayoutParams(lp);
		HEIGHT=px;
	}
	public int getWidth(int px)
	{
		return WIDTH;
	}

	public int getHeight(int px)
	{
		return HEIGHT;
	}
	
	public int dpi(float dp)
	{
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	public static int dp(Context ctx, float dp)
	{
		float scale = ctx.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showMenu() {
		close.setRotation(0);
		isHide = false;
		parentBox.removeAllViews();
		parentBox.addView(menulayout, WIDTH, HEIGHT);
	}
	
	public void hideMenu() {
		close.setRotation(-90);
		isHide = true;
		parentBox.removeAllViews();
		parentBox.addView(menulayout, WIDTH, dpi(25));
	}
	
	public int addPage(String text) {
		PageButton page = new PageButton(context, text);
		pageslayout.addView(page.line);
		final int pageid = pageButts.size();
		page.setOnClick(new OnClickListener() {
			public void onClick(View v) {
				showPage(pageid);
			}
		});
		pageButts.add(page);

		
		LinearLayout pageLayout = new LinearLayout(context);
		pageLayout.setOrientation(LinearLayout.VERTICAL);
		pageLayout.setPadding(10,10,10,10);
		pageLayout.setVisibility(View.GONE);
		
		pageList.add(pageLayout);
		pagelayout.addView(pageLayout, -1, -1);
		return pageList.size() - 1;
	}
	
	public void showPage(int id) {
		for (int i = 0; i < pageButts.size(); i++) {
			pageButts.get(i).setChecked(false);
			pageList.get(i).setVisibility(View.GONE);
		}
		pageButts.get(id).setChecked(true);
		pageList.get(id).setVisibility(View.VISIBLE);
	}
	
	public void newCheck(int pageid, String text, OnClickListener call) {
		Switch cl = new Switch(context, text, false);
		cl.setOnClick(call);
		pageList.get(pageid).addView(cl.line);
	}
	
	public void newSlider(int pageid, String text, int mx, int cr, Slider.Callback call) {
		Slider cl = new Slider(context, text, mx, cr, call);
		pageList.get(pageid).addView(cl.lined);
	}
	
	public void newInput(int pageid, int lineid, int feat,final String text, float size, final AlertInput.onChange call) {
		CustomButton cl = new CustomButton(context, feat, text, size, new CustomButton.buttonClick() {
				public void onClick(int featr) {
					new AlertInput (context, text, call);
				}
			});
		pageList.get(pageid).addView(cl.getLine());
	}
	
	public static native String yaicaware();
	public Menu(Context context)
	{
		init(context);
		

		WIDTH = dpi(360);
		HEIGHT = dpi(250);

		final GradientDrawable shit = new GradientDrawable();
		shit.setColor(Color.parseColor("#777777"));
		
		menulayout = new LinearLayout(context);
		menulayout.setOrientation(LinearLayout.VERTICAL);
		
		headerlayout = new LinearLayout(context);
		headerlayout.setGravity(Gravity.CENTER_VERTICAL);
		headerlayout.setBackgroundColor(Color.parseColor(colorPurple));
		
		close = new ImageView(context);
		close.setRotation(-90);
		setImageFromAssets(close, "arrow.png");
		close.setPadding(5,5,5,5);
		
		title = new TextView(context);
		title.setText(yaicaware());
		title.setTextColor(Color.WHITE);
		title.setTextSize(16f);
		title.setTypeface(font(context));
		title.setGravity(Gravity.CENTER_VERTICAL);
		title.setClickable(false);
		
		headerlayout.addView(close, dpi(20), dpi(20));
		headerlayout.addView(title, -2, -1);
		
		
		menulayout.addView(headerlayout, -1, dpi(25));
		
		mainlayout = new LinearLayout(context);
		mainlayout.setOrientation(LinearLayout.VERTICAL);
		menulayout.addView(mainlayout, -1, -1);
		
		GradientDrawable grad = new GradientDrawable();
		grad.setColor(Color.parseColor(colorDark));
		grad.setStroke(3, Color.parseColor(colorPurple));
		
		mainlayout.setBackgroundDrawable(grad);
		mainlayout.setPadding(10,10,10,10);
		
		OnClickListener clck = (new OnClickListener() {
			public void onClick(View v){
				if (isHide) {
					showMenu();
				} else {
					hideMenu();
				}
			}
		});
		close.setOnClickListener(clck);
		title.setOnClickListener(clck);
		
		pageslayout = new LinearLayout(context);
		pageslayout.setOrientation(LinearLayout.HORIZONTAL);
		pageslayout.setGravity(Gravity.BOTTOM);
		
		mainlayout.addView(pageslayout, -1, dpi(20));
		
		LinearLayout line = new LinearLayout(context);
		line.setBackgroundColor(Color.parseColor(colorPurple));
		mainlayout.addView(line, -1, 1);
		
		scrollItems = new ScrollView(context);
		pagelayout = new LinearLayout(context);
		
		scrollItems.addView(pagelayout, -1, -1);
		
		mainlayout.addView(scrollItems, -1, -1);
		
		showMenu();
		wmManager.addView(parentBox, wmParams);
		
		//menu.showPage(0);
	}



	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
			}
			return true;
		}
	};
	public static interface ibt {
        void OnWrite();
    }
	
	public static interface iit {
        void OnWrite(int i);
    }
	
	private int convertDipToPixels(int i) {
        return (int) ((((float) i) * context.getResources().getDisplayMetrics().density) + 0.5f);
    }
}
