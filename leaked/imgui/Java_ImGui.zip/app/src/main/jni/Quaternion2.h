/* leak by t.me/yaicaware */
/* t.me/yaicaware */
/* github.com/initfault/yaicaware */

#pragma once

using namespace std;
#include <math.h>
#include <iostream>
#include "Canvas/StructsCommon.h"

#define SMALL_FLOAT 0.0000000001

struct Quaternion2
{
    union
    {
        struct
        {
            float x;
            float y;
            float z;
            float w;
        };
        float data[4];
    };


    /**
     * Constructors.
     */
    inline Quaternion2();
    inline Quaternion2(float data[]);
    inline Quaternion2(Vector3 vector, float scalar);
    inline Quaternion2(float x, float y, float z, float w);
    inline Quaternion2(float Pitch, float Yaw, float Roll);


    /**
     * Constants for common Quaternion2s.
     */
    static inline Quaternion2 Identity();

    /**
     * The following let you quickly get a direction vector from a quat.
     */
    static inline Vector3 Up(Quaternion2 q);
    static inline Vector3 Down(Quaternion2 q);
    static inline Vector3 Left(Quaternion2 q);
    static inline Vector3 Right(Quaternion2 q);
    static inline Vector3 Forward(Quaternion2 q);
    static inline Vector3 Back(Quaternion2 q);


    /**
     * Returns the angle between two Quaternion2s.
     * The Quaternion2s must be normalized.
     * @param a: The first Quaternion2.
     * @param b: The second Quaternion2.
     * @return: A scalar value.
     */
    static inline float Angle(Quaternion2 a, Quaternion2 b);

    /**
     * Returns the conjugate of a Quaternion2.
     * @param rotation: The Quaternion2 in question.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 Conjugate(Quaternion2 rotation);

    /**
     * Returns the dot product of two Quaternion2s.
     * @param lhs: The left side of the multiplication.
     * @param rhs: The right side of the multiplication.
     * @return: A scalar value.
     */
    static inline float Dot(Quaternion2 lhs, Quaternion2 rhs);

    /**
     * Creates a new Quaternion2 from the angle-axis representation of
     * a rotation.
     * @param angle: The rotation angle in radians.
     * @param axis: The vector about which the rotation occurs.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 FromAngleAxis(float angle, Vector3 axis);

    /**
     * Create a new Quaternion2 from the euler angle representation of
     * a rotation. The z, x and y values represent rotations about those
     * axis in that respective order.
     * @param rotation: The x, y and z rotations.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 FromEuler(Vector3 rotation);

    /**
     * Create a new Quaternion2 from the euler angle representation of
     * a rotation. The z, x and y values represent rotations about those
     * axis in that respective order.
     * @param x: The rotation about the x-axis in radians.
     * @param y: The rotation about the y-axis in radians.
     * @param z: The rotation about the z-axis in radians.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 FromEuler(float x, float y, float z);

    /**
     * Create a Quaternion2 rotation which rotates "fromVector" to "toVector".
     * @param fromVector: The vector from which to start the rotation.
     * @param toVector: The vector at which to end the rotation.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 FromToRotation(Vector3 fromVector,
                                            Vector3 toVector);

    /**
     * Returns the inverse of a rotation.
     * @param rotation: The Quaternion2 in question.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 Inverse(Quaternion2 rotation);

    /**
     * Interpolates between a and b by t, which is clamped to the range [0-1].
     * The result is normalized before being returned.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 Lerp(Quaternion2 a, Quaternion2 b, float t);

    /**
     * Interpolates between a and b by t. This normalizes the result when
     * complete.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 LerpUnclamped(Quaternion2 a, Quaternion2 b,
                                           float t);

    /**
     * Creates a rotation with the specified forward direction. This is the
     * same as calling LookRotation with (0, 1, 0) as the upwards vector.
     * The output is undefined for parallel vectors.
     * @param forward: The forward direction to look toward.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 LookRotation(Vector3 forward);

    /**
     * Creates a rotation with the specified forward and upwards directions.
     * The output is undefined for parallel vectors.
     * @param forward: The forward direction to look toward.
     * @param upwards: The direction to treat as up.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 LookRotation(Vector3 forward, Vector3 upwards);

    /**
     * Returns the norm of a Quaternion2.
     * @param rotation: The Quaternion2 in question.
     * @return: A scalar value.
     */
    static inline float Norm(Quaternion2 rotation);

    /**
     * Returns a Quaternion2 with identical rotation and a norm of one.
     * @param rotation: The Quaternion2 in question.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 Normalized(Quaternion2 rotation);

    /**
     * Returns a new Quaternion2 created by rotating "from" towards "to" by
     * "maxRadiansDelta". This will not overshoot, and if a negative delta is
     * applied, it will rotate till completely opposite "to" and then stop.
     * @param from: The rotation at which to start.
     * @param to: The rotation at which to end.
     # @param maxRadiansDelta: The maximum number of radians to rotate.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 RotateTowards(Quaternion2 from, Quaternion2 to,
                                           float maxRadiansDelta);

    /**
     * Returns a new Quaternion2 interpolated between a and b, usinfg spherical
     * linear interpolation. The variable t is clamped to the range [0-1]. The
     * resulting Quaternion2 will be normalized.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 Slerp(Quaternion2 a, Quaternion2 b, float t);

    /**
     * Returns a new Quaternion2 interpolated between a and b, usinfg spherical
     * linear interpolation. The resulting Quaternion2 will be normalized.
     * @param a: The starting rotation.
     * @param b: The ending rotation.
     * @param t: The interpolation value.
     * @return: A new Quaternion2.
     */
    static inline Quaternion2 SlerpUnclamped(Quaternion2 a, Quaternion2 b,
                                            float t);

    /**
     * Outputs the angle axis representation of the provided Quaternion2.
     * @param rotation: The input Quaternion2.
     * @param angle: The output angle.
     * @param axis: The output axis.
     */
    static inline void ToAngleAxis(Quaternion2 rotation, float &angle,
                                   Vector3 &axis);

    /**
     * Returns the Euler angle representation of a rotation. The resulting
     * vector contains the rotations about the z, x and y axis, in that order.
     * @param rotation: The Quaternion2 to convert.
     * @return: A new vector.
     */
    static inline Vector3 ToEuler(Quaternion2 rotation);

    /**
     * Operator overloading.
     */
    inline struct Quaternion2& operator+=(const float rhs);
    inline struct Quaternion2& operator-=(const float rhs);
    inline struct Quaternion2& operator*=(const float rhs);
    inline struct Quaternion2& operator/=(const float rhs);
    inline struct Quaternion2& operator+=(const Quaternion2 rhs);
    inline struct Quaternion2& operator-=(const Quaternion2 rhs);
    inline struct Quaternion2& operator*=(const Quaternion2 rhs);
};

inline Quaternion2 operator-(Quaternion2 rhs);
inline Quaternion2 operator+(Quaternion2 lhs, const float rhs);
inline Quaternion2 operator-(Quaternion2 lhs, const float rhs);
inline Quaternion2 operator*(Quaternion2 lhs, const float rhs);
inline Quaternion2 operator/(Quaternion2 lhs, const float rhs);
inline Quaternion2 operator+(const float lhs, Quaternion2 rhs);
inline Quaternion2 operator-(const float lhs, Quaternion2 rhs);
inline Quaternion2 operator*(const float lhs, Quaternion2 rhs);
inline Quaternion2 operator/(const float lhs, Quaternion2 rhs);
inline Quaternion2 operator+(Quaternion2 lhs, const Quaternion2 rhs);
inline Quaternion2 operator-(Quaternion2 lhs, const Quaternion2 rhs);
inline Quaternion2 operator*(Quaternion2 lhs, const Quaternion2 rhs);
inline Vector3 operator*(Quaternion2 lhs, const Vector3 rhs);
inline bool operator==(const Quaternion2 lhs, const Quaternion2 rhs);
inline bool operator!=(const Quaternion2 lhs, const Quaternion2 rhs);



/*******************************************************************************
 * Implementation
 */

Quaternion2::Quaternion2() : x(0), y(0), z(0), w(1) {}
Quaternion2::Quaternion2(float data[]) : x(data[0]), y(data[1]), z(data[2]),
                                       w(data[3]) {}
Quaternion2::Quaternion2(Vector3 vector, float scalar) : x(vector.X),
                                                       y(vector.Y), z(vector.Z), w(scalar) {}
Quaternion2::Quaternion2(float x, float y, float z, float w) : x(x), y(y),
                                                             z(z), w(w) {}
Quaternion2::Quaternion2(float Pitch, float Yaw, float Roll) {
    Quaternion2 tmp = Quaternion2::FromEuler(Pitch, Yaw, Roll);
    x = tmp.x;
    y = tmp.y;
    z = tmp.z;
    w = tmp.w;
}



inline Vector3 Quaternion2::Up(Quaternion2 q)
{
    return q * Vector3::Up();
}

inline Vector3 Quaternion2::Down(Quaternion2 q)
{
    return q * Vector3::Down();
}

inline Vector3 Quaternion2::Left(Quaternion2 q)
{
    return q * Vector3::Left();
}

inline Vector3 Quaternion2::Right(Quaternion2 q)
{
    return q * Vector3::Right();
}

inline Vector3 Quaternion2::Forward(Quaternion2 q)
{
    return q * Vector3::Forward();
}

inline Vector3 Quaternion2::Back(Quaternion2 q)
{
    return q * Vector3::Backward();
}

float Quaternion2::Angle(Quaternion2 a, Quaternion2 b)
{
    float dot = Dot(a, b);
    return acosf(fminf(fabs(dot), 1)) * 2;
}

Quaternion2 Quaternion2::Conjugate(Quaternion2 rotation)
{
    return Quaternion2(-rotation.x, -rotation.y, -rotation.z, rotation.w);
}

float Quaternion2::Dot(Quaternion2 lhs, Quaternion2 rhs)
{
    return lhs.x * rhs.x + lhs.y * rhs.y + lhs.z * rhs.z + lhs.w * rhs.w;
}

Quaternion2 Quaternion2::FromAngleAxis(float angle, Vector3 axis)
{
    Quaternion2 q;
    float m = sqrt(axis.X * axis.X + axis.Y * axis.Y + axis.Z * axis.Z);
    float s = sinf(angle / 2) / m;
    q.x = axis.X * s;
    q.y = axis.Y * s;
    q.z = axis.Z * s;
    q.w = cosf(angle / 2);
    return q;
}

Quaternion2 Quaternion2::FromEuler(Vector3 rotation)
{
    return FromEuler(rotation.X, rotation.Y, rotation.Z);
}

Quaternion2 Quaternion2::FromEuler(float x, float y, float z)
{
    float cx = cosf(x * 0.5f);
    float cy = cosf(y * 0.5f);
    float cz = cosf(z * 0.5f);
    float sx = sinf(x * 0.5f);
    float sy = sinf(y * 0.5f);
    float sz = sinf(z * 0.5f);
    Quaternion2 q;
    q.x = cx * sy * sz + cy * cz * sx;
    q.y = cx * cz * sy - cy * sx * sz;
    q.z = cx * cy * sz - cz * sx * sy;
    q.w = sx * sy * sz + cx * cy * cz;
    return q;
}

Quaternion2 Quaternion2::FromToRotation(Vector3 fromVector, Vector3 toVector)
{
    float dot = Vector3::Dot(fromVector, toVector);
    float k = sqrt(Vector3::SqrMagnitude(fromVector) *
                   Vector3::SqrMagnitude(toVector));
    if (fabs(dot / k + 1) < 0.00001)
    {
        Vector3 ortho = Vector3::Orthogonal(fromVector);
        return Quaternion2(Vector3::Normalized(ortho), 0);
    }
    Vector3 cross = Vector3::Cross(fromVector, toVector);
    return Normalized(Quaternion2(cross, dot + k));
}

Quaternion2 Quaternion2::Inverse(Quaternion2 rotation)
{
    float n = Norm(rotation);
    return Conjugate(rotation) / (n * n);
}

Quaternion2 Quaternion2::Lerp(Quaternion2 a, Quaternion2 b, float t)
{
    if (t < 0) return Normalized(a);
    else if (t > 1) return Normalized(b);
    return LerpUnclamped(a, b, t);
}

Quaternion2 Quaternion2::LerpUnclamped(Quaternion2 a, Quaternion2 b, float t)
{
    Quaternion2 Quaternion2;
    if (Dot(a, b) >= 0)
        Quaternion2 = a * (1 - t) + b * t;
    else
        Quaternion2 = a * (1 - t) - b * t;
    return Normalized(Quaternion2);
}

Quaternion2 Quaternion2::LookRotation(Vector3 forward)
{
    return LookRotation(forward, Vector3(0, 1, 0));
}

Quaternion2 Quaternion2::LookRotation(Vector3 forward, Vector3 upwards)
{
    // Normalize inputs
    forward = Vector3::Normalized(forward);
    upwards = Vector3::Normalized(upwards);
    // Don't allow zero vectors
    if (Vector3::SqrMagnitude(forward) < SMALL_FLOAT || Vector3::SqrMagnitude(upwards) < SMALL_FLOAT)
        return Quaternion2(0, 0, 0, 1);
    // Handle alignment with up direction
    if (1 - fabs(Vector3::Dot(forward, upwards)) < SMALL_FLOAT)
        return FromToRotation(Vector3::Forward(), forward);
    // Get orthogonal vectors
    Vector3 right = Vector3::Normalized(Vector3::Cross(upwards, forward));
    upwards = Vector3::Cross(forward, right);
    // Calculate rotation
    Quaternion2 Quaternion2;
    float radicand = right.X + upwards.Y + forward.Z;
    if (radicand > 0)
    {
        Quaternion2.w = sqrt(1.0f + radicand) * 0.5f;
        float recip = 1.0f / (4.0f * Quaternion2.w);
        Quaternion2.x = (upwards.Z - forward.Y) * recip;
        Quaternion2.y = (forward.X - right.Z) * recip;
        Quaternion2.z = (right.Y - upwards.X) * recip;
    }
    else if (right.X >= upwards.Y && right.X >= forward.Z)
    {
        Quaternion2.x = sqrt(1.0f + right.X - upwards.Y - forward.Z) * 0.5f;
        float recip = 1.0f / (4.0f * Quaternion2.x);
        Quaternion2.w = (upwards.Z - forward.Y) * recip;
        Quaternion2.z = (forward.X + right.Z) * recip;
        Quaternion2.y = (right.Y + upwards.X) * recip;
    }
    else if (upwards.Y > forward.Z)
    {
        Quaternion2.y = sqrt(1.0f - right.X + upwards.Y - forward.Z) * 0.5f;
        float recip = 1.0f / (4.0f * Quaternion2.y);
        Quaternion2.z = (upwards.Z + forward.Y) * recip;
        Quaternion2.w = (forward.X - right.Z) * recip;
        Quaternion2.x = (right.Y + upwards.X) * recip;
    }
    else
    {
        Quaternion2.z = sqrt(1.0f - right.X - upwards.Y + forward.Z) * 0.5f;
        float recip = 1.0f / (4.0f * Quaternion2.z);
        Quaternion2.y = (upwards.Z + forward.Y) * recip;
        Quaternion2.x = (forward.X + right.Z) * recip;
        Quaternion2.w = (right.Y - upwards.X) * recip;
    }
    return Quaternion2;
}

float Quaternion2::Norm(Quaternion2 rotation)
{
    return sqrt(rotation.x * rotation.x +
                rotation.y * rotation.y +
                rotation.z * rotation.z +
                rotation.w * rotation.w);
}

Quaternion2 Quaternion2::Normalized(Quaternion2 rotation)
{
    return rotation / Norm(rotation);
}

Quaternion2 Quaternion2::RotateTowards(Quaternion2 from, Quaternion2 to,
                                     float maxRadiansDelta)
{
    float angle = Quaternion2::Angle(from, to);
    if (angle == 0)
        return to;
    maxRadiansDelta = fmaxf(maxRadiansDelta, angle - (float)M_PI);
    float t = fminf(1, maxRadiansDelta / angle);
    return Quaternion2::SlerpUnclamped(from, to, t);
}

Quaternion2 Quaternion2::Slerp(Quaternion2 a, Quaternion2 b, float t)
{
    if (t < 0) return Normalized(a);
    else if (t > 1) return Normalized(b);
    return SlerpUnclamped(a, b, t);
}

Quaternion2 Quaternion2::SlerpUnclamped(Quaternion2 a, Quaternion2 b, float t)
{
    float n1;
    float n2;
    float n3 = Dot(a, b);
    bool flag = false;
    if (n3 < 0)
    {
        flag = true;
        n3 = -n3;
    }
    if (n3 > 0.999999)
    {
        n2 = 1 - t;
        n1 = flag ? -t : t;
    }
    else
    {
        float n4 = acosf(n3);
        float n5 = 1 / sinf(n4);
        n2 = sinf((1 - t) * n4) * n5;
        n1 = flag ? -sinf(t * n4) * n5 : sinf(t * n4) * n5;
    }
    Quaternion2 Quaternion2;
    Quaternion2.x = (n2 * a.x) + (n1 * b.x);
    Quaternion2.y = (n2 * a.y) + (n1 * b.y);
    Quaternion2.z = (n2 * a.z) + (n1 * b.z);
    Quaternion2.w = (n2 * a.w) + (n1 * b.w);
    return Normalized(Quaternion2);
}

void Quaternion2::ToAngleAxis(Quaternion2 rotation, float &angle, Vector3 &axis)
{
    if (rotation.w > 1)
        rotation = Normalized(rotation);
    angle = 2 * acosf(rotation.w);
    float s = sqrt(1 - rotation.w * rotation.w);
    if (s < 0.00001) {
        axis.X = 1;
        axis.Y = 0;
        axis.Z = 0;
    } else {
        axis.X = rotation.x / s;
        axis.Y = rotation.y / s;
        axis.Z = rotation.z / s;
    }
}

Vector3 Quaternion2::ToEuler(Quaternion2 rotation)
{
    float sqw = rotation.w * rotation.w;
    float sqx = rotation.x * rotation.x;
    float sqy = rotation.y * rotation.y;
    float sqz = rotation.z * rotation.z;
    // If normalized is one, otherwise is correction factor
    float unit = sqx + sqy + sqz + sqw;
    float test = rotation.x * rotation.w - rotation.y * rotation.z;
    Vector3 v;
    // sinfgularity at north pole
    if (test > 0.4995f * unit)
    {
        v.Y = 2 * atan2f(rotation.y, rotation.x);
        v.X = (float)M_PI_2;
        v.Z = 0;
        return v;
    }
    // sinfgularity at south pole
    if (test < -0.4995f * unit)
    {
        v.Y = -2 * atan2f(rotation.y, rotation.x);
        v.X = -(float)M_PI_2;
        v.Z = 0;
        return v;
    }
    // yaw
    v.Y = atan2f(2 * rotation.w * rotation.y + 2 * rotation.z * rotation.x,
                 1 - 2 * (rotation.x * rotation.x + rotation.y * rotation.y));
    // Pitch
    v.X = asinf(2 * (rotation.w * rotation.x - rotation.y * rotation.z));
    // Roll
    v.Z = atan2f(2 * rotation.w * rotation.z + 2 * rotation.x * rotation.y,
                 1 - 2 * (rotation.z * rotation.z + rotation.x * rotation.x));
    return v;
}

struct Quaternion2& Quaternion2::operator+=(const float rhs)
{
    x += rhs;
    y += rhs;
    z += rhs;
    w += rhs;
    return *this;
}

struct Quaternion2& Quaternion2::operator-=(const float rhs)
{
    x -= rhs;
    y -= rhs;
    z -= rhs;
    w -= rhs;
    return *this;
}

struct Quaternion2& Quaternion2::operator*=(const float rhs)
{
    x *= rhs;
    y *= rhs;
    z *= rhs;
    w *= rhs;
    return *this;
}

struct Quaternion2& Quaternion2::operator/=(const float rhs)
{
    x /= rhs;
    y /= rhs;
    z /= rhs;
    w /= rhs;
    return *this;
}

struct Quaternion2& Quaternion2::operator+=(const Quaternion2 rhs)
{
    x += rhs.x;
    y += rhs.y;
    z += rhs.z;
    w += rhs.w;
    return *this;
}

struct Quaternion2& Quaternion2::operator-=(const Quaternion2 rhs)
{
    x -= rhs.x;
    y -= rhs.y;
    z -= rhs.z;
    w -= rhs.w;
    return *this;
}

struct Quaternion2& Quaternion2::operator*=(const Quaternion2 rhs)
{
    Quaternion2 q;
    q.w = w * rhs.w - x * rhs.x - y * rhs.y - z * rhs.z;
    q.x = x * rhs.w + w * rhs.x + y * rhs.z - z * rhs.y;
    q.y = w * rhs.y - x * rhs.z + y * rhs.w + z * rhs.x;
    q.z = w * rhs.z + x * rhs.y - y * rhs.x + z * rhs.w;
    *this = q;
    return *this;
}

Quaternion2 operator-(Quaternion2 rhs) { return rhs * -1; }
Quaternion2 operator+(Quaternion2 lhs, const float rhs) { return lhs += rhs; }
Quaternion2 operator-(Quaternion2 lhs, const float rhs) { return lhs -= rhs; }
Quaternion2 operator*(Quaternion2 lhs, const float rhs) { return lhs *= rhs; }
Quaternion2 operator/(Quaternion2 lhs, const float rhs) { return lhs /= rhs; }
Quaternion2 operator+(const float lhs, Quaternion2 rhs) { return rhs += lhs; }
Quaternion2 operator-(const float lhs, Quaternion2 rhs) { return rhs -= lhs; }
Quaternion2 operator*(const float lhs, Quaternion2 rhs) { return rhs *= lhs; }
Quaternion2 operator/(const float lhs, Quaternion2 rhs) { return rhs /= lhs; }
Quaternion2 operator+(Quaternion2 lhs, const Quaternion2 rhs)
{
    return lhs += rhs;
}
Quaternion2 operator-(Quaternion2 lhs, const Quaternion2 rhs)
{
    return lhs -= rhs;
}
Quaternion2 operator*(Quaternion2 lhs, const Quaternion2 rhs)
{
    return lhs *= rhs;
}

Vector3 operator*(Quaternion2 lhs, const Vector3 rhs)
{
    Vector3 u = Vector3(lhs.x, lhs.y, lhs.z);
    float s = lhs.w;
    return u * (Vector3::Dot(u, rhs) * 2.0f)
           + rhs * (s * s - Vector3::Dot(u, u))
           + Vector3::Cross(u, rhs) * (2.0f * s);
}

bool operator==(const Quaternion2 lhs, const Quaternion2 rhs)
{
    return lhs.x == rhs.x &&
           lhs.y == rhs.y &&
           lhs.z == rhs.z &&
           lhs.w == rhs.w;
}

bool operator!=(const Quaternion2 lhs, const Quaternion2 rhs)
{
    return !(lhs == rhs);
}
