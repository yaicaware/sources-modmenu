#pragma once

#include "vector2.h"

struct RaycastHit {
    Vector3 Point, Normal;
    std::uint32_t FaceID;
    float Distance;
    Vector2 UV;
    int32_t m_Collider;
};

std::string to_string(RaycastHit a) {
    return "a";
}
