extern "C" {
	
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_getUsers(
        JNIEnv *env,
        jobject activityObject) {
            //Devices List URL with Text
            XorS(vwv, "https://pastebin.com/raw/2NaUCm9s");
    jstring str = env->NewStringUTF(vwv.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_vwv(
        JNIEnv *env,
        jobject activityObject) {
            XorS(vwv, "android.intent.action.VIEW");
    jstring str = env->NewStringUTF(vwv.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_cant(
        JNIEnv *env,
        jobject activityObject) {
            XorS(cant, "");
    jstring str = env->NewStringUTF(cant.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_sum(
        JNIEnv *env,
        jobject activityObject) {
            XorS(sum, "Отправить хвид");
    jstring str = env->NewStringUTF(sum.decrypt());
    return str;
}
    
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_lenk(
        JNIEnv *env,
        jobject activityObject) {
            XorS(lenk, "https://t.me/Arf1ocheks");
    jstring str = env->NewStringUTF(lenk.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_byu(
        JNIEnv *env,
        jobject activityObject) {
            XorS(byu, "Купить чит");
    jstring str = env->NewStringUTF(byu.decrypt());
    return str;
}


JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_msgs(
        JNIEnv *env,
        jobject activityObject) {
            XorS(msgs, "BUY CHEAT! | ");
    jstring str = env->NewStringUTF(msgs.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_msgss(
        JNIEnv *env,
        jobject activityObject) {
            XorS(msgss, "isn't allowed to Continue!\n \nBuy the cheat to play with it!\n \nYour Device Information (IP, Map Loc Coordinate, Full Phone Information and etc. ) has logged to server, because of trying to authenticate with unknown device");
    jstring str = env->NewStringUTF(msgss.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_unk(
        JNIEnv *env,
        jobject activityObject) {
            XorS(unk, "Unknown User :");
    jstring str = env->NewStringUTF(unk.decrypt());
    return str;
}
    
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_out(
        JNIEnv *env,
        jobject activityObject) {
            XorS(out, "Выход");
    jstring str = env->NewStringUTF(out.decrypt());
    return str;
}
    
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_err(
        JNIEnv *env,
        jobject activityObject) {
            XorS(errr, "Error occurred!");
    jstring str = env->NewStringUTF(errr.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_tosti(
        JNIEnv *env,
        jobject activityObject) {
            XorS(tosti, "Authorized Successfully!");
    jstring str = env->NewStringUTF(tosti.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l1(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o1, "DeviceID");
    jstring str = env->NewStringUTF(o1.decrypt());
    return str;
}
    
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l2(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o2, "Manufacturer");
    jstring str = env->NewStringUTF(o2.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l3(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o3, "Model");
    jstring str = env->NewStringUTF(o3.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l4(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o4, "Host");
    jstring str = env->NewStringUTF(o4.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l5(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o5, "Product");
    jstring str = env->NewStringUTF(o5.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l6(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o6, "AndroidVersion");
    jstring str = env->NewStringUTF(o6.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l7(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o7, "Hardware");
    jstring str = env->NewStringUTF(o7.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l8(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o8, "Fingerprint");
    jstring str = env->NewStringUTF(o8.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_l9(
        JNIEnv *env,
        jobject activityObject) {
            XorS(o9, "Operator");
    jstring str = env->NewStringUTF(o9.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_dot(
        JNIEnv *env,
        jobject activityObject) {
            XorS(dt, " : ");
    jstring str = env->NewStringUTF(dt.decrypt());
    return str;
}

JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_space(
        JNIEnv *env,
        jobject activityObject) {
            XorS(spc, " | ");
    jstring str = env->NewStringUTF(spc.decrypt());
    return str;
}
}
