/* leak by t.me/yaicaware */
/* t.me/yaicaware */
/* github.com/initfault/yaicaware */

#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <Chams.h>
#include <vector>
#include "Includes/XorS.h"
#include "Canvas/ESP.h"
#include "Canvas/Bools.h"
#include "Canvas/StructsCommon.h"

extern "C" {

JNIEXPORT jstring JNICALL
Java_seitaku_StaticActivity_getUsers(
        JNIEnv *env,
        jobject activityObject) {
			//Devices List URL with Text
			XorS(vwv, "https://pastebin.com/raw/XCuV5HvY");
    jstring str = env->NewStringUTF(vwv.decrypt());
    return str;
}



/*Time For Bools And all*/

const char *libName = "libil2cpp.so";

JNIEXPORT jstring JNICALL Java_seitaku_Main_apk(JNIEnv *env, jobject activityObject) {
    jstring str = env->NewStringUTF("yaicaware");// do not earse the space this for normal text view
    return str;
}

JNIEXPORT jstring JNICALL Java_seitaku_modmenu_Menu_yaicaware(JNIEnv *env, jobject activityObject) {
    jstring s2tr = env->NewStringUTF("yaicaware");// do not earse the space this for normal text view
    return s2tr;
}

std::string test = "";

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}


struct My_Patches {MemoryPatch;} hexPatches;

JNIEXPORT jobjectArray  JNICALL Java_seitaku_Main_getFeatures(JNIEnv *env, jobject activityObject) {
	jobjectArray ret;
	
//switch_vkladka_func_text
//slider_vkladka_func_text_max_min
	
	const char *features[] = {
		"page_yaicaware", // 0
		"page_ImGui", // 1
		
		//page 1
		
		"switch_0_1_Switch",
		"slider_0_2_Slider_1_2",
		
		//page 2
		
		"switch_1_3_Switch 2",
	    "slider_1_4_Slider 1_1_2",
		
		
	};
	int Total_Feature = (sizeof features /
						 sizeof features[0]); //Now you dont have to manually update the number everytime;
	
	ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
	int i;
	for (i = 0; i < Total_Feature; i++)
		env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
	return (ret);
}

JNIEXPORT void JNICALL
Java_seitaku_Main_Changes(JNIEnv *env,jobject activityObject,jint feature,jint value) {
	/*  FEATURES  */
	switch (feature) {
	}
}

}
// ---------- Hooking ---------- //

void *hack_thread(void *) {
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
    // ---------- Hook ---------- //
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
