bool equals(std::string target, std::string search) {
 if (target.find(search) != std::string::npos){
  return true;
 } else {
  return false;
 }
}

bool contains(std::string target, std::string search) {
	if (target.find(search)) {
		return true;
	} else {
		return false;
	}
}

bool isLength(std::string from, int value) {
 if (from.length() == value) {
  return true;
 } else {
  return false;
 }
}

std::string gen_random(const int len) {
    static const char alphanum[] =
        "0123456789abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);
    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    return tmp_s;
}

std::string signature = "lcG7acvUIg0k4FQSQmAbyw1tN0o=";

void (*old_safestring)(void* inst, monoString* value, uint KeyLength);
void safestring(void* inst, monoString* value, uint KeyLength){
	if (inst != NULL){
		std::string valtostd = value->get_string();
			if (isLength(valtostd, signature.length())){
				value = CreateMonoString(signature.c_str());
			} else if (equals(valtostd, "=")){
				value = CreateMonoString(gen_random(16).c_str());
			} else if (contains(valtostd, "base.apk:") && (equals(valtostd, "|main.2040.com.axlebolt.standoff2.obb:"))){
				value = CreateMonoString("base.apk:319ea83d263443c1c459cc15431e69cd:88567877|main.2040.com.axlebolt.standoff2.obb:133ccecc558892a3c69e58806a389206:1735709108");
		}
		LOGI("%s", value->get_string().c_str());
	} 
	return old_safestring(inst, value, KeyLength);
}

MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x973718), (void *) safestring, (void **)&old_safestring);
	
