#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <vector>
#include "RGB.h"
#include "Quaternion2.h"

#include "Canvas/ESP.h"
#include "Canvas/Bools.h"
#include "Canvas/StructsCommon.h"

void *(*get_main) ();
Vector3 (*get_screenpos) (void *cam, Vector3 inst);
void (*set_localRotation) (void* instanceObj, Quaternion2 rotate);
Vector3 (*get_position) (void* inst);
void (*set_position) (void *tr, Vector3 poss);
bool *(*get_transform) (void* inst);
void *(*send_grenade) (void* inst, Vector2 rt, Vector3 ps);
bool (*checkRaycast) (void* po, Vector3 pos, float maxdist);

extern "C" {
	
	
JNIEXPORT jstring JNICALL
Java_il2cpp_StaticActivity_getUsers(JNIEnv *env, jobject activityObject) {
    jstring s2tr = env->NewStringUTF("yaicaware");// do not earse the space this for normal text view
    return s2tr;
}


char* libName = "libil2cpp.so";
ESP espOverlay;
vector<void*> players;
int handX = 100;
int handY = 100;
int handZ = 100;
bool hand = false;
int int_max = 2147483647;

struct My_Patches {MemoryPatch Noclip, MoveBT, BuyZone, Attach, NoSpawn;} hexPatches;

bool antifyuman = false;

JNIEXPORT jstring JNICALL
Java_il2cpp_Main_getTitle(JNIEnv *env, jobject activityObject) {
	return env->NewStringUTF("t.me/yaicaware");
}
struct myChams {
bool Chams, Outline = false;

bool ChamsR, ChamsG, ChamsB, ChamsY, ChamsP, ChamsW, OutlR, OutlG, OutlB, OutlY, OutlP,  OutlW = false;
} chams;

struct myBoolsEsp {
	bool Tracer, Box, Name, Health = false;
	bool Fill, Corner = false;
	int FillR, FillG, FillB, Radius = 0;
	int TracerWidth, TracerR, TracerG, TracerB = 0;
	int BoxWidth, BoxR, BoxG, BoxB = 0;
	int FillA = 255;
	int NameSize, NameR, NameG, NameB, HealthSize = 0;
	bool OnlyTeam = false;
	int Team = 0;
	bool BoxRain, FillRain, TracerRain, NickRain = false;
	bool Shadow = false;
} esp;

struct myBoolsMove {
	bool allwpn, attach = false;
	bool prime1, prime2 = false;
	bool goMap, gamemode, goCmd = false;
	string MapName = "bloxpoligon";
	string CmdName = "tw 73";
	bool Noclip, MoveBT, BuyZone, NoSpawn, JumpHack, Bhop, NoKick = false;
} moveP;

struct myAutoBuy {
	bool buy = false;
	int rifle = 0;
	int pistol = 0;
	int grenade = 0;
	int knife = 0;
	
	int rifles[8] = {0, 1, 32, 33, 34, 23, 51, 54};
	int pistols[4] = {0, 2, 12, 15};
	int grenades[4] = {0, 64, 65, 66};
	int knifes[8] = {0, 69, 3, 72, 76, 68, 73, 86};
} abuy;

struct myBoolsWpn {
	bool NoRecoil, NoSpread, FireRate, noKick = false;
} wpnP;

struct myGreande {
	Vector2 rot;
	Vector3 pos;
	bool copy, paste, throwg = false;
} grenade;

struct myWpnSkins {
	int ak47 = 0;
	int m4a4 = 0;
	int m4a1 = 0;
	int an94 = 0;
	int deagle = 0;
	int revolver = 0;
	int awp = 0;
	int sscout = 0;
	
	int ak47s[12] = {0, 1, 12, 21, 76, 82, 97, 126, 130, 135, 167, 169};
	int m4a4s[13] = {0, 15, 17, 43, 44, 65, 73, 81, 125, 128, 155, 173, 174};
	int m4a1s[4]  = {0, 23, 33, 121};
	int an94s[4]  = {0, 39, 96, 165};
	int deagles[9] = {0, 2, 20, 35, 55, 85, 127, 166, 179};
	int revolvers[6] = {0, 102, 103, 107, 151, 162};
	int awps[14] = {0, 13, 19, 32, 34, 40, 45, 69, 70, 84, 91, 131, 156, 180};
	int sscouts[6] = {0, 6, 7, 64, 88, 163};
} skins;

struct MyWpnGive {
	int id, slot, skin = 0;
	bool give, select = false;
} give;

struct MyWpnGive2 {
	int id = 0;
	bool give = false;
} give2;

struct MyAimBool {
	bool Aim, Fov, DrawFov = false;
	float aimY = 1.0f;
	int fovValue, Team = 0;
	bool FovRain = false;
} aim;

struct MyScreenVars {
	int Width, Height = 0;
	string Text = "github.com/initfault";
} screen;

struct myCrossVars {
	bool Show = false;
	int Width = 20;
	int Height = 20;
	int LineWidth = 2;
	int Red, Green, Blue;
} crosshair;

void giveSkin(int slot, int id, int skin) {
	give.give = true;
	give.slot = slot;
	give.skin = skin;
	give.id   = id;
}

void giveSkin2(int id) {
	give2.give = true;
	give2.id   = id;
}

struct myAnimP {
	bool copy = false;
	bool paste = false;
} anim;

struct NyAvaCh {
	bool change = false;
	int id = 1;
} ava;

std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

void hexChange(bool &var, MemoryPatch &patch) {
	var = !var;
	if (var) {
		patch.Modify();
	} else {
		patch.Restore();
	}
}

string ticcket = "e090012320722bee779bd1adb8fac43c";

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

std::string fto_string(float param) {
	std::string str = "";
	int num = (int) (param * 100);
	str = to_string(num);
	if (str.size() > 2) str.insert(str.size() - 2, ",");
	return str;
}

JNIEXPORT jobjectArray  JNICALL
Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) { jobjectArray ret;
    // PAGE_Name_Icon_Lines
	// SWITCH_Page_Line_Feature_Text_Size
	// SLIDER_Page_Line_Feature_Text_Min_Max_Current_Size
	// BUTTON_Page_Line_Feature_Text_Size
	// INPUT_Page_Line_Feature_Text_Size
	// TITLE_Page_Line_Text_Size
	// ARROW_Page_Line_Feature_Texts_Size
	
    const char *features[] = {
            "PAGE_Player_player.png_2",   // 0
			"PAGE_Visuals_visuals.png_2", // 1
			"PAGE_Other_cfg.png_1", // 2
			"PAGE_Test_yaica.png_1", // 3
			// ------ Player  > 0 ------  //
			//"TITLE_0_0_Weapon_13"
           "TITLE_0_0_Player_12",
		   "SWITCH_0_0_20000_Rapid Fire_13",
           "SWITCH_0_0_20000_Air Jump_13",
		   "SWITCH_0_0_20000_Drop Knife_13",
		   "SWITCH_0_0_20000_Radar Hack_13",
		   "SWITCH_0_0_20000_WallShot_13",
		   "SWITCH_0_0_20000_No Recoil 25%_13",
		   "SWITCH_0_0_20000_No Recoil 50%_13",
		   "SWITCH_0_0_20000_No Recoil 75%_13",
		   "SWITCH_0_0_20000_No Recoil 100%_13",
           "TITLE_0_1_CHAMS_12",
		   "SWITCH_0_1_20000_Chams_13",//20000
		   "SLIDER_0_1_20001_Color Red_0_255_0_9",//20001
		   "SLIDER_0_1_20002_Color Green_0_255_0_9",//20002
		   "SILDER_0_1_20003_Color Blue_0_255_0_9",//20003
		   "SLIDER_0_1_20004_Color Yellow_0_255_0_9",//20004
		   "SLIDER_0_1_20005_Color Pink_0_255_0_9",//20005
		   "SLIDER_0_1_20005_Color White_0_255_0_9",//20006
		   "TITLE_0_1_OUTLINE_12",
		   "SWITCH_0_1_20012_Outline_13",//20012
		   "SLIDER_0_1_20006_Color Red_0_255_0_9",//20006
		   "SLIDER_0_1_20007_Color Green_0_255_0_9",//20007
		   "SLIDER_0_1_20008_Color Blue_0_255_0_9",//20008
		   "SLIDER_0_1_20009_Color Yellow_0_255_0_9",//20009
		   "SLIDER_0_1_20010_Color Pink_0_255_0_9",//20010
		   "SLIDER_0_1_20011_Color White_0_255_0_9",//20011
		   
			// ------ Visuals > 1 ------ //
			"TITLE_1_0_Esp Box_12",
			"SWITCH_1_0_1_Enable_13",
			"SLIDER_1_0_2_Line width_0_3_0_9",
			"SLIDER_1_0_3_Color red_0_255_0_9",
			"SLIDER_1_0_4_Color green_0_255_0_9",
			"SLIDER_1_0_5_Color blue_0_255_0_9",
			"SWITCH_1_0_333_Shadow (-fps)_10",
			"SWITCH_1_0_1101_Rainbow_11",
			
			"TITLE_1_0_Box Fill_12",
			"SWITCH_1_0_200_Rect fill_11",
			"SLIDER_1_0_201_Fill red_0_255_0_9",
			"SLIDER_1_0_202_Fill green_0_255_0_9",
			"SLIDER_1_0_203_Fill blue_0_255_0_9",
			"SLIDER_1_0_204_Fill alpha_0_255_255_9",
			"SWITCH_1_0_1102_Rainbow_11",
			"TITLE_1_0_Box Corner_12",
			"SWITCH_1_0_205_Corner_12",
			"SLIDER_1_0_206_Radius_0_100_0_11",
			
			"TITLE_1_0_Esp Tracer_12",
			"SWITCH_1_0_6_Enable_13",
			"SLIDER_1_0_7_Line width_0_3_0_9",
			"SLIDER_1_0_8_Color red_0_255_0_9",
			"SLIDER_1_0_9_Color green_0_255_0_9",
			"SLIDER_1_0_10_Color blue_0_255_0_9",
			"SWITCH_1_0_1103_Rainbow_11",
			
			"TITLE_1_1_Esp Name_12",
			"SWITCH_1_1_11_Enable_13",
			"SLIDER_1_1_12_Text size_0_50_0_9",
			"SLIDER_1_1_13_Color red_0_255_0_9",
			"SLIDER_1_1_14_Color green_0_255_0_9",
			"SLIDER_1_1_15_Color blue_0_255_0_9",
			"SWITCH_1_1_1104_Rainbow_11",
			
			"TITLE_1_1_Health bar_12",
			"SWITCH_1_1_16_Enable_13",
			"SLIDER_1_1_20_Health size_0_50_0_9",
			
			"TITLE_1_1_Esp Team_12",
			"SWITCH_1_1_17_Only team esp_9",
			"BUTTON_1_1_18_Only CT_12",
			"BUTTON_1_1_19_Only TT_12",
			
			// ------ OTHER > 2 ------ //
			
			"TITLE_2_0_Menu_12",
			"SWITCH_2_0_22222_Drop Knife_13",//22222
			"SWITCH_2_0_22223_Radar Hack_13",//22223
			"SWITCH_2_0_22224_Speed Hack_13",//22224
			"SLIDER_2_0_22225_set speed_0_30_0_9",//22225
			"SWITCH_2_0_22226_Set Bomb_13",//22226
			"SWITCH_2_0_22227_Plant anywere_13",//22227
			"SWITCH_2_0_22228_Fast Bomb_13",//22228
			"SWITCH_2_0_22229_Defuse anywere_13",//22229
			"SWITCH_2_0_22230_Auto Defuse_13",//22230
			"SWITCH_2_0_22231_More before time_13",//22231
			"SWITCH_2_0_22232_Green People_13",//22232
			//"TITLE_3_1_Server hack_13",
			//"SWITCH_3_1_1651_Desync_13",
			
			// ------ yaicaware > 3 ------ //
			
			"TITLE_3_0_yaicaware_12",
			"ARROW_3_0_1337_yaica, ware_13",//22222
			"BUTTON_3_0_1337_yaicaware_13",//22223
			"INPUT_3_0_1337_yaicaware input_13",//22224
			"SLIDER_3_0_1337_yaicaware_0_100_50_9",//22225
			
			
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 
bool logg, desync = false;

JNIEXPORT void JNICALL
Java_il2cpp_Main_OnChange(JNIEnv *env, jobject activityObject, jint feature, jint value, jstring strv, jboolean check) {jobjectArray ret;
	std::string str_value = jstring2string(env, strv);
	switch (feature) {
		
		case 915:
			logg = check;
			break;
		case 1651:
			desync = check;
			break;
		
		case 15001:
			abuy.rifle = abuy.rifles[value];
			break;
		case 15002:
			abuy.pistol = abuy.pistols[value];
			break;
		case 15003:
			abuy.grenade = abuy.grenades[value];
			break;
		case 15005:
			abuy.knife = abuy.knifes[value];
			break;
		case 15004:
			abuy.buy = true;
			break;
		
		case 5401:
			ava.id = value;
			break;
		case 5402:
			ava.change = check;
			break;
		
		case 4051:
			give2.id = value;
			break;
		case 4052:
			give2.give = true;
			break;
		
		case 14001:
			giveSkin2(69);
			break;
		case 14002:
			giveSkin2(3);
			break;
		case 14003:
			giveSkin2(68);
			break;
		case 14004:
			giveSkin2(72);
			break;
		case 14005:
			giveSkin2(76);
			break;
		case 14006:
			giveSkin2(73);
			break;
		case 14007:
			giveSkin2(86);
			break;
		case 14008:
			giveSkin2(77);
			break;
		case 14009:
			giveSkin2(78);
			break;
			
		case 1611:
			anim.copy = true;
			break;
		case 1612:
			anim.paste = check;
			break;
			
		case 1601:
			grenade.copy = true;
			break;
		case 1602:
			grenade.paste = check;
			break;
		case 1603:
			grenade.throwg = true;
			break;
		case 1604:
			giveSkin2(64);
			break;
		case 1605:
			giveSkin2(65);
			break;
		case 1606:
			giveSkin2(66);
			break;
		
		case 2201:
			moveP.prime1 = check;
			break;
		case 2202:
			moveP.prime2 = check;
			break;
		case 2203:
			moveP.allwpn = check;
			break;
		
		case 1401:
			moveP.MapName = str_value;
			break;
		case 1402:
			moveP.goMap = true;
			break;
		case 1403:
			moveP.gamemode = check;
			break;
		case 1404:
			moveP.CmdName = str_value;
			break;
		case 1405:
			moveP.goCmd = true;
			break;
		case 1406:
			give.id = std::atoi(str_value.c_str());
			break;
		case 1407:
			give.skin = std::atoi(str_value.c_str());
			break;
		case 1408:
			give.slot = 2;
			give.give = true;
			break;
		case 2210:
			moveP.attach = !check;
			hexChange(moveP.attach, hexPatches.Attach);
			break;
		
		case 914:
			antifyuman = check;
			break;
		
		case 1501:
			skins.ak47 = skins.ak47s[value];
			break;
		case 1502:
			skins.m4a4 = skins.m4a4s[value];
			break;
		case 1503:
			skins.an94 = skins.an94s[value];
			break;
		case 1504:
			skins.m4a1 = skins.m4a1s[value];
			break;
		case 1505:
			skins.deagle = skins.deagles[value];
			break;
		case 1506:
			skins.revolver = skins.revolvers[value];
			break;
		case 1507:
			skins.awp = skins.awps[value];
			break;
		case 1508:
			skins.sscout = skins.sscouts[value];
			break;
			
		
		case 1001:
			giveSkin(2, 69, 77);
			break;
		case 1002:
			giveSkin(2, 69, 78);
			break;
		case 1003:
			giveSkin(2, 69, 79);
			break;
		case 1004:
			giveSkin(2, 69, 80);
			break;
		
		case 1005:
			giveSkin(2, 76, 152);
			break;
		case 1006:
			giveSkin(2, 76, 153);
			break;
		case 1007:
			giveSkin(2, 76, 154);
			break;
		
		case 1008:
			giveSkin(2, 3, 56);
			break;
		case 1009:
			giveSkin(2, 3, 95);
			break;
		case 1010:
			giveSkin(2, 3, 134);
			break;
		
		case 1011:
			giveSkin(2, 72, 114);
			break;
		case 1012:
			giveSkin(2, 72, 115);
			break;
	
		case 4501:
			aim.FovRain = check;
			break;
			
		case 1013:
			giveSkin(2, 73, 182);
			break;
		
		case 1014:
			giveSkin(2, 68, 129);
			break;
		case 1015:
			giveSkin(2, 68, 168);
			break;
		
		case 1:
			esp.Box = check;
			break;
		case 2:
			esp.BoxWidth = value;
			break;
		case 3:
			esp.BoxR = value;
			break;
		case 4:
			esp.BoxG = value;
			break;
		case 5:
			esp.BoxB = value;
			break;
			
		case 6:
			esp.Tracer = check;
			break;
		case 7:
			esp.TracerWidth = value;
			break;
		case 8:
			esp.TracerR = value;
			break;
		case 9:
			esp.TracerG = value;
			break;
		case 10:
			esp.TracerB = value;
			break;
		
		case 11:
			esp.Name = check;
			break;
		case 12:
			esp.NameSize = value;
			break;
		case 13:
			esp.NameR = value;
			break;
		case 14:
			esp.NameG = value;
			break;
		case 15:
			esp.NameB = value;
			break;
		
		case 16:
			esp.Health = check;
			break;
		
		case 17:
			esp.OnlyTeam = check;
			break;
		case 18:
			esp.Team = 0;
			break;
		case 19:
			esp.Team = 1;
			break;
		
		case 20:
			esp.HealthSize = value;
			break;
		
		case 21:
			moveP.Noclip = !check;
			hexChange(moveP.Noclip, hexPatches.Noclip);
			break;
		case 23:
			moveP.MoveBT = !check;
			hexChange(moveP.MoveBT, hexPatches.MoveBT);
			break;
		case 22:
			moveP.BuyZone = !check;
			hexChange(moveP.BuyZone, hexPatches.BuyZone);
			break;
		case 24:
			moveP.NoSpawn = !check;
			hexChange(moveP.NoSpawn, hexPatches.NoSpawn);
			break;
		case 25:
			moveP.Bhop = check;
			break;
		case 26:
			moveP.JumpHack = check;
			break;
		case 27:
			wpnP.noKick = check;
			break;
		
		case 28:
			wpnP.NoRecoil = check;
			break;
		case 29:
			wpnP.NoSpread = check;
			break;
		case 30:
			wpnP.FireRate = check;
			break;
			
		case 31:
			handX = value;
			break;
		case 32:
			handY = value;
			break;
		case 33:
			handZ = value;
			break;
		case 34:
			hand = check;
			break;
		
		case 40:
			aim.Aim = check;
			break;
		case 41:
			aim.aimY = 0.35;
			break;
		case 42:
			aim.aimY = 0.80;
			break;
		case 43:
			aim.aimY = (float)(((float)value) / 100);
			screen.Text = fto_string(aim.aimY);
			break;
		
		case 45:
			aim.fovValue = value;
			break;
		case 46:
			aim.DrawFov = check;
			break;
		
		case 47:
			aim.Team = 0;
			break;
		case 48:
			aim.Team = 1;
			break;
		
		case 49:
			crosshair.Show = check;
			break;
		case 50:
			crosshair.LineWidth = value;
			break;
		case 51:
			crosshair.Red = value;
			break;
		case 52:
			crosshair.Green = value;
			break;
		case 53:
			crosshair.Blue = value;
			break;
		case 54:
			crosshair.Width = value;
			break;
		
		case 205:
			esp.Corner = check;
			break;
		case 206:
			esp.Radius = value;
			break;
		
		case 200:
			esp.Fill = check;
			break;
		case 201:
			esp.FillR = value;
			break;
		case 202:
			esp.FillG = value;
			break;
		case 203:
			esp.FillB = value;
			break;
		case 204:
			esp.FillA = value;
			break;
		
		case 333:
			esp.Shadow = check;
			break;
		
		case 1101:
			esp.BoxRain = check;
			break;
		case 1102:
			esp.FillRain = check;
			break;
		case 1103:
			esp.TracerRain = check;
			break;
		case 1104:
			esp.NickRain = check;
			break;
				
		case 6601:
			logg = check;
			break;
		
	}
}

using namespace std;std::string utf16le_to_utf8(const std::u16string &u16str) {    if (u16str.empty()) { return std::string(); }    const char16_t *p = u16str.data();    std::u16string::size_type len = u16str.length();    if (p[0] == 0xFEFF) {        p += 1;        len -= 1;    }    std::string u8str;    u8str.reserve(len * 3);    char16_t u16char;    for (std::u16string::size_type i = 0; i < len; ++i) {        u16char = p[i];        if (u16char < 0x0080) {            u8str.push_back((char) (u16char & 0x00FF));            continue;        }        if (u16char >= 0x0080 && u16char <= 0x07FF) {            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }        if (u16char >= 0xD800 && u16char <= 0xDBFF) {            uint32_t highSur = u16char;            uint32_t lowSur = p[++i];            uint32_t codePoint = highSur - 0xD800;            codePoint <<= 10;            codePoint |= lowSur - 0xDC00;            codePoint += 0x10000;            u8str.push_back((char) ((codePoint >> 18) | 0xF0));            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));            continue;        }        {            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }    }    return u8str;}typedef struct _monoString {    void *klass;    void *monitor;    int length;    const char *toChars(){        u16string ss((char16_t *) getChars(), 0, getLength());        string str = utf16le_to_utf8(ss);        return str.c_str();    }    char chars[0];    char *getChars() {        return chars;    }    int getLength() {        return length;    }    std::string get_string() {                return std::string(toChars());    }} monoString;monoString *CreateMonoString(const char *str) {    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0x17FDA04);     return String_CreateString(NULL, str);}

bool isFov(Vector2 vec1, Vector2 vec2, int radius) {
	int x = vec1.X;
	int y = vec1.Y;
	
	int x0 = vec2.X;
	int y0 = vec2.Y;
	if ( (pow(x - x0, 2) + pow(y - y0, 2) ) <= pow(radius, 2) ) {
		return true;
	} else {
		return false;
	}
}

JNIEXPORT void JNICALL
Java_il2cpp_typefaces_Menu_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
	espOverlay = ESP(env, espView, canvas);
	if (espOverlay.isValid()){
		
	}
} 

}
// ---------- Hooking ---------- //
monoString* (*Ticket)(void* instance);
monoString* Auth(void* instance) {
    if (instance != NULL) {
        return CreateMonoString(ticcket.c_str());
    }
}
 



void *hack_thread(void *) {
	
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
	MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x1239980), (void *) Auth, (void **) &Ticket); 
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
	
	_JavaVM* publicJVM = vm; 
	publicJVM->GetEnv((void **) &globalEnv, JNI_VERSION_1_6); 
	
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
