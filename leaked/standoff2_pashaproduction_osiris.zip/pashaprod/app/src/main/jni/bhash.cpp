extern "C" {
    JNIEXPORT jobjectArray JNICALL
    Java_com_axlebolt_service_ServiceStarter_startService(
    JNIEnv* env,
    jobject ez,
    jobjectArray ArrayS) {
        jobjectArray ret;
        int yikesCount = env->GetArrayLength(ArrayS);
        const char* hashes[5];
        for (int i = 0; i < yikesCount; i++) {
            jstring yikes = (jstring) (env->GetObjectArrayElement(ArrayS, i));
            const char *prco = env->GetStringUTFChars(yikes, 0);
            hashes[i] = prco;
        }
        int arsize = (sizeof hashes / sizeof hashes[0]);
        ret = (jobjectArray) env->NewObjectArray(arsize, env->FindClass("java/lang/String"), env->NewStringUTF(""));
        int o;
        for (o = 0; o < arsize; o++) {
            if (contains(hashes[o], "classes.dex")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("2484292274"));         
            } else if (contains(hashes[o], "resources.arsc")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("312719833"));
            } else if (contains(hashes[o], "AndroidManifest.xml")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("3946138737"));
            } else if (contains(hashes[o], "META-INF/MANIFEST.MF")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("428633349"));
            } else if (contains(hashes[o], "META-INF/CERT.SF")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("92968632"));
            } 
        }
        return ret;
    }
}

.method public static native startService([Ljava/lang/String;)[Ljava/lang/String;
.end method

.method public static getHash(Landroid/content/Context;[Ljava/lang/String;)[Ljava/lang/String;
    .registers 5
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "strArr"    # [Ljava/lang/String;

    .line 21
    move-object v0, p0

    .line 22
    .local v0, "context2":Landroid/content/Context;
    array-length v1, p1

    new-array v1, v1, [Ljava/lang/String;

    .line 23
    .local v1, "strArr2":[Ljava/lang/String;
    invoke-static {p1}, Lcom/axlebolt/service/ServiceStarter;->startService([Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method
