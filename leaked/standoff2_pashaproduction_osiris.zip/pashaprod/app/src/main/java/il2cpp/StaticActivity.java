/* leak by t.me/yaicaware */

package il2cpp;

import android.annotation.*;
import android.content.*;
import android.os.*;
import android.os.Process;
import android.content.*;
import android.app.*;
import java.util.*;
import android.provider.Settings;
import android.util.Base64;
import java.io.UnsupportedEncodingException;
import android.os.Build.*;
import android.widget.*;
import android.graphics.*;
import java.io.*;
import android.telephony.TelephonyManager;
import android.text.*;
import android.net.*;
import android.util.*;
import java.net.*;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
//import il2cpp.additional.TOKEN;
import java.util.zip.ZipInputStream;
import android.content.ClipboardManager;

@SuppressLint("StaticFieldLeak")
public class StaticActivity extends AsyncTask<String, Void, String> {


	static {
        // When you change the lib name, change also on Android.mk file
        // Both must have same name
		System.loadLibrary("Takina");

	}

	private static final String TAG = "yaicaware";
    public static String cacheDir;
	static Context context;
	//private static native String msgs();
	private static native String vwv();
	private static native String cant();
	private static native String niran();
	//private static native String unk();
	//private static native String msgss();
	private static native String tosti();
	private static native String Toast2();
	//private static native String out();
	private static native String lenk();

	/*private static native String byu();
	 private static native String l1();
	 private static native String l2();
	 private static native String l3();
	 private static native String l4();
	 private static native String l5();
	 private static native String l6();
	 private static native String l7();
	 private static native String l8();
	 private static native String l9();
	 private static native String dot();
	 private static native String space();*/
	private static native String getUsers();
	//private String dot = dot();
	//private String space = space();
	public static String getDevices = getUsers();

	StaticActivity(Context paramContext) {

		this.context = paramContext;

	}
	
	public boolean vpn() {
		String iface = "";
		try {
			for (NetworkInterface networkInterface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
				if (networkInterface.isUp())
					iface = networkInterface.getName();
				if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					return true;
				}
			}
		} catch (SocketException e1) {
			e1.printStackTrace();
		}
		return false;
	}

	public String urlRequest(String str) {
        StringBuilder sb = new StringBuilder();
        try {

			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(str).openConnection().getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
                //sb.append("\n");
            }
            bufferedReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    @Override
    protected String doInBackground(String... strings) {
        URL url;
        String fetched = null;
        try {
            url = new URL(strings[0]);
            HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null){
                fetched = line;
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return fetched;
    }

	@Override
    protected void onPostExecute(String paramString) {
		super.onPostExecute(paramString);
		if (paramString.toString().contains(result())) {
			Toast.makeText(context, Html.fromHtml("You have successfully logged in!"), Toast.LENGTH_LONG).show();
			Main.start(context);
		} else {
			ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
			ClipData clip = ClipData.newPlainText("", result().toString());
			clipboard.setPrimaryClip(clip);
			final AlertDialog.Builder builder2 = new AlertDialog.Builder(context);
			builder2.setTitle(Html.fromHtml("<b><font color='red'>"+ "Unknown User: "+getModel()+"</b></font>"));
			builder2.setCancelable(false);
			
			
			builder2.setMessage(Html.fromHtml("<b><font color='black'>"+ "This Device "+getModel()+" isn't allowed to Continue!\n \nYour Device ID has been copied to clipboard!"));
								

			builder2.show();
		}

	}


	public String result() {
		final String val = "|" + getDeviceID() + "|" + getNetworkOperator() + "|" + getFingerprint() + "|" + getHardware() + "|" + getHost() + "|" + getManufacturer() + "|" + getModel() + "|" + getOsVersion() + "|" + getProduct() + "|";
		return val + ",";
	}

	public String getNetworkOperator() {
        final String bee = context.getApplicationContext() != null ? ((TelephonyManager) context.getApplicationContext().getSystemService("phone")).getNetworkOperatorName() : "";
		final String bee2 = context.getApplicationContext() != null ? ((TelephonyManager) context.getApplicationContext().getSystemService("phone")).getNetworkOperator() : "";
		return bee + " " + bee2;
    }
	public String getDeviceID() {
		final String android_id = android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
		return android_id;
	}
	public String getFingerprint() {
        return android.os.Build.FINGERPRINT;
    }

	public String getHardware() {
        return android.os.Build.HARDWARE;
    }
    public String getHost() {
        return android.os.Build.HOST;
    }
    public String getManufacturer() {
        return android.os.Build.MANUFACTURER;
    }
    public String getModel() {
        return android.os.Build.MODEL;
    }
    public String getOsVersion() {
        return android.os.Build.VERSION.RELEASE;
    }
    public String getProduct() {
        return android.os.Build.PRODUCT;
    }
    public String getUniqueEventId() {
        return UUID.randomUUID().toString();
    }
    @Override
    public void onProgressUpdate(Void... voidArr) {
        super.onProgressUpdate(voidArr);
    }



    public static void MakeClearFile(final Context context, String filenames) {
        File direct = new File(Environment.getExternalStorageDirectory() + "/Android/data/com.axlebolt.standoff2/files/il2cpp/Metadata/");
		File file = new File(Environment.getExternalStorageDirectory() + filenames);
		if(!direct.exists()) {
			direct.mkdir();
		}        
		try {
			file.createNewFile();
			FileOutputStream f = new FileOutputStream(file);
			PrintWriter pw = new PrintWriter(f);
			pw.flush();
			pw.close();
			f.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }


    public static void Start(final Context context) {
		System.loadLibrary("Takina");
        Handler handler5 = new Handler();
        handler5.postDelayed(new Runnable() {
				@Override
				public void run() {
			//		new StaticActivity(context).execute(getDevices);
			
			        Main.start(context);
				}
			}, 1000);
    }
}
