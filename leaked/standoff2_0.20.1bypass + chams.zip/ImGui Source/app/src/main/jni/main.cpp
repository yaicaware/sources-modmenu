#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <Chams.h>
#include <vector>
#include "Includes/XorS.h"
#include <Includes/Logger.h>
#include "Canvas/ESP.h"
#include <Monostring.h>
#include "Canvas/Bools.h"
#include "Canvas/StructsCommon.h"

extern "C" {


const char *libName = "libil2cpp.so";
bool chams, wireframe, glow, outline, rainbow228 = false;

bool rapid_fire, switch_token, air_jump, money_hack, chams_bypass, infinity_ammo, infinity_shop, xp_hack, friendly_fire, fast_bomb, fast_plant, buy_any_where, infinity_grenades, dont_return_to_spawn, spoof_name, spoof_clan, spoof_uid, speed_hack, infinity_magazine = false;
bool gloves_neuro, gloves_autumn, gloves_phoenix, gloves_geometric, gloves_retrowave, gloves_livingflame = false;
JNIEXPORT jstring JNICALL Java_il2cpp_Main_apk(JNIEnv *env, jobject activityObject) {
    jstring str = env->NewStringUTF("ywh");
    return str;
}

std::string test = "";

std::string enter_token = "";

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

JNIEXPORT void JNICALL
Java_il2cpp_TOKEN_TOKEN(JNIEnv *env, jclass clazz, jobject VVVVSJSBSNS) {
    // TODO: implement getContext()

    jclass EC567E = env->FindClass("il2cpp/TOKEN");
    jmethodID EB46BD = env->GetStaticMethodID(EC567E, "getUserToken", "(Landroid/content/Context;)Ljava/lang/String;");
    jobject E1B28C = env->CallStaticObjectMethod(EC567E, EB46BD, VVVVSJSBSNS);
    const char* BC1568 = env->GetStringUTFChars((jstring) E1B28C, nullptr);
 
   enter_token = BC1568;

 LOGI("%s", enter_token.c_str());
   
   
 }


struct My_Patches {MemoryPatch Chams_bypass;} hexPatches;

JNIEXPORT jobjectArray  JNICALL Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) {
	jobjectArray ret;
	const char *features[] = {
		"page_test apk v1", 

		"switch_0_1_Default chams",
		"switch_0_2_Wireframe chams",
		"switch_0_3_Glow chams",
		"switch_0_4_Outline chams",
		"switch_0_5_Rainbow chams",
		"switch_0_27_Wallhack chams",
		"slider_0_6_Outline width_12_0",
		"slider_0_7_R_255_0",
		"slider_0_8_G_255_0",
		"slider_0_9_B_255_0",
		
		
	};
	int Total_Feature = (sizeof features /
						 sizeof features[0]);
	
	ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
	int i;
	for (i = 0; i < Total_Feature; i++)
		env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
	return (ret);
}

JNIEXPORT void JNICALL
Java_il2cpp_Main_Changes(JNIEnv *env,jobject activityObject,jint feature,jint value) {
	switch (feature) {
		case 1:
			chams = !chams;
				if (chams){
					SetWallhack(true);
				} else {
					SetWallhack(false);
				}
				break;
		case 2:
			wireframe = !wireframe;
				if (wireframe){
					SetWallhackW(true);
				} else {
					SetWallhackW(false);
				}
				break;

		case 3: 
        	glow = !glow;
        		if (glow) {
        			SetWallhackG(true);
        		} else {
        			SetWallhackG(false);
       			}
        		break;
        
        case 4: 
        	outline = !outline;
        		if (outline) {
        			SetWallhackO(true);
        		} else {
        			SetWallhackO(false);
       			}
       			break;

        case 5: 
        	rainbow228 = !rainbow228;
        		if (rainbow228) {
        			SetRainbow(true);
        		} else {
        			SetRainbow(false);
        		}
        		break;
        
        case 6: 
        	SetW(value);
        		break;
                    
        case 7:
        	SetR(value);
        		break;
  
        case 8:
        	SetG(value);
        		break;

        case 9:
        	SetB(value);
        		break;

   
	case 27:
		chams_bypass = !chams_bypass;
			if (chams_bypass){
				hexPatches.Chams_bypass.Modify();
			} else {
				hexPatches.Chams_bypass.Restore();
					break;
        		}

		}
	}

}




bool equals(std::string target, std::string search) {
 if (target.find(search) != std::string::npos){
  return true;
 } else {
  return false;
 }
}

bool contains(std::string target, std::string search) {
	if (target.find(search)) {
		return true;
	} else {
		return false;
	}
}

JNIEXPORT jobjectArray JNICALL
    Java_com_axlebolt_service_ServiceStarter_startService(
    JNIEnv* env,
    jobject ez,
    jobjectArray ArrayS) {
        jobjectArray ret;
        int yikesCount = env->GetArrayLength(ArrayS);
        const char* hashes[5];
        for (int i = 0; i < yikesCount; i++) {
            jstring yikes = (jstring) (env->GetObjectArrayElement(ArrayS, i));
            const char *prco = env->GetStringUTFChars(yikes, 0);
            hashes[i] = prco;
        }
        int arsize = (sizeof hashes / sizeof hashes[0]);
        ret = (jobjectArray) env->NewObjectArray(arsize, env->FindClass("java/lang/String"), env->NewStringUTF(""));
        int o;
        for (o = 0; o < arsize; o++) {
            if (contains(hashes[o], "classes.dex")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("2484292274"));         
            } else if (contains(hashes[o], "resources.arsc")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("312719833"));
            } else if (contains(hashes[o], "AndroidManifest.xml")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("3946138737"));
            } else if (contains(hashes[o], "META-INF/MANIFEST.MF")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("428633349"));
            } else if (contains(hashes[o], "META-INF/CERT.SF")) {
                env->SetObjectArrayElement(ret, o, env->NewStringUTF("92968632"));
            } 
        }
        return ret;
    }

bool isLength(std::string from, int value) {
 if (from.length() == value) {
  return true;
 } else {
  return false;
 }
}

std::string gen_random(const int len) {
    static const char alphanum[] =
        "0123456789abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);
    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    return tmp_s;
}



std::string signature = "lcG7acvUIg0k4FQSQmAbyw1tN0o=";


/*

void replaceAll(std::string& str, const std::string& from, const std::string& to) {
    if(from.empty())
        return;
    size_t start_pos = 0;
    while((start_pos = str.find(from, start_pos)) != std::string::npos) {
        str.replace(start_pos, from.length(), to);
        start_pos += to.length();
    }
}
*/

typedef std::string yikes;

void (*old_safestring)(void* inst, monoString* value, uint KeyLength);
void safestring(void* inst, monoString* value, uint KeyLength){
	if (inst != NULL){
		std::string valtostd = value->get_string();
		//yikes valtostd(b->toChars());
			if (isLength(valtostd, signature.length())){
				value = CreateMonoString(signature.c_str());
			} else if (equals(valtostd, "=")){
				value = CreateMonoString(gen_random(16).c_str());
			} else if (contains(valtostd, "base.apk:") && (equals(valtostd, "|main.2040.com.axlebolt.standoff2.obb:"))){
				value = CreateMonoString("base.apk:319ea83d263443c1c459cc15431e69cd:88567877|main.2040.com.axlebolt.standoff2.obb:133ccecc558892a3c69e58806a389206:1735709108");
			} else if (valtostd.find("/data/") && (valtostd.find("data/")) && (valtostd.find("com.axlebolt.standoff2/")) && (valtostd.find("cache/")) && (valtostd.find(".so")) != std::string::npos){
				std::string path_to_detect = "/data/data/com.axlebolt.standoff2/cache/libENGINEER.so";
				if (valtostd.find(path_to_detect)){
					std::string basicString;
            		basicString += ReplaceString(valtostd, (path_to_detect + "|"), "");
            		value = CreateMonoString(basicString.c_str());
				}
			} else if (contains(valtostd, "/data/") && contains(valtostd, ".so") && contains(valtostd, "|")) {
        yikes lib1 = "/data/data/com.axlebolt.standoff2/cache/libmain.so";
        yikes lib2 = "/data/user/0/com.axlebolt.standoff2/cache/libmain.so";
        if (contains(valtostd, lib1)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib1 + "|"), "");
            value = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd,lib2)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib2 + "|"), "");
            value = CreateMonoString(basicString.c_str());
        }
    
		
		}
		LOGI("%s", value->get_string().c_str());
	} 
	return old_safestring(inst, value, KeyLength);
}



bool (*authorization_with_token_system_general)(void* inst);
bool authorization_with_token_system(void* inst){
	if (inst != NULL){
		*(monoString **)((uint64_t) inst + 0x6C) = CreateMonoString(enter_token.c_str());
		}
	return true;	
}


bool (*vk)();
bool vkk(){
	return false;
}

bool (*google)();
bool googlee(){
	return false;
}

bool (*fb)();
bool fbb(){
	return false;
}



    	


void *hack_thread(void *) {
	
	
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
setShader("_BumpMap");

LogShaders();
Wallhack();
    //-------- token
   //it isn't working, old offsets
   // offset from 0.19.3 f1
MSHookFunction((void *) getAbsoluteAddress(libName, 0xC009CC), (void *) authorization_with_token_system,
    	(void **) &authorization_with_token_system_general);

  //offsets from 0.19.4 f1
	MSHookFunction((void *) getAbsoluteAddress(libName, 0xF91E28), (void *) vkk,
    	(void **) &vk);
		
	MSHookFunction((void *) getAbsoluteAddress(libName, 0xF91C30), (void *) google,
    	(void **) &google);
		
	MSHookFunction((void *) getAbsoluteAddress(libName, 0xF91AE0), (void *) fbb,
    	(void **) &fb);
    //---------- token

	MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x973718), (void *) safestring, (void **)&old_safestring);
 
	hexPatches.Chams_bypass = MemoryPatch::createWithHex("libil2cpp.so", 0xA44258, "1E FF 2F E1");

    return NULL;
}


JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);


    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}

