JNIEXPORT jobjectArray  JNICALL
    Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) {
    jobjectArray ret; 
    const char *features[] = {
            OBFUSCATE(
            "CRASH_version : 0.18.6 F2 | V1"),//0
            "CRASH_M9 Bayonet Knife",//1
            "HL1_M9 Dragon Glass",//2
            "HL2_M9 Universe",//3
            "HL2_M9 Ancient",//4
            "HL2_M9 Frozen",//5
            "HL2_M9 Scratch",//6
            "HL2_M9 Blue Blood",//7
            "CRASH_Butterfly Knife",//8
            "HL2_Butterfly Fire Storm",//9
            "HL2_Butterfly Legacy",//10
            "HL2_Butterfly Dragon Glass",//11
            "HL2_Butterfly Cold Flame",//12
            "HL2_Butterfly Starfall",//13
            "HL1_Butterfly Black Widow",//14
            "CRASH_Karambit Knife",//15
            "HL2_Karambit Gold",//16
            "HL2_Karambit Claw",//17
            "HL2_Karambit Dragon Glass",//18
            "HL2_Karambit Scratch",//19
            "HL2_Karambit Universe",//20
            "HL2_Karambit Snow Camo",//21
            "HL2_Karambit Cold Flame",//22
            "HL2_Karambit Frozen",//23
            "CRASH_jKommando Knife",//24
            "HL2_jKommando Luxury",//25
            "HL2_jKommando Reaper",//26
            "HL2_jKommando Floral",//27
            "HL2_jKommando Ancient",//28
            "HL2_jKommando Frozen",//29
            "CRASH_Flip Knife",//30
            "HL2_FlipKnife Snow Camo",//31
            "HL2_FlipKnife Dragon Glass",//32
            "HL2_FlipKnife Arctic",//33
            "HL2_FlipKnife Stone Cold",//34
            "HL2_FlipKnife Vortex",//35
            "HL2_FlipKnife Frozen",//36
            "CRASH_Kunai Knife",//37
            "HL2_Kunai Poison",//38
            "HL2_Kunai Luxury",//39
            "HL2_Kunai Bone",//40
            "HL2_Kunai Reaper",//41
            "HL2_Kunai Radiation",//42
            "HL2_Kunai Cold Flame",//43
            "HL2_Kunai Snow Camo",//44
            "CRASH_Scorpion Knife",//45
            "HL2_Scorpion Scratch",//46
            "HL2_Scorpion Camouflage",//47
            "HL2_Scorpion Green",//48
            "HL2_Scorpion Sky",//49
            "HL2_Scorpion Cold Flame",//50
            "CRASH_Set Weapons",//51
            "HL2_G22 Nest",//52
            "HL2_USP 2 Years Red",//53
            "HL2_P350 Poison",//54
            "HL2_Desert Eagle Mafia",//55
            "HL2_Tec 9 Fable",//56
            "HL2_F/S Venom",//57
            "HL2_UMP45 Cyberpunk",//58
            "HL2_MP7 2 Years Red",//59
            "HL2_P90 Samurai",//60
            "HL2_MP5 Zone",//61
            "HL1_AKR 2 Years",//62
            "HL2_AKR12 Geometric",//63
            "HL2_M4 Necromancer",//64
            "HL2_M16 Winged",//65
            "HL2_Famas Monster",//66
            "HL2_FnFal Phoenix",//67
            "HL1_AWM Treasure Hunter",//68
            "HL2_M40 Monster",//69
            "HL2_M110 Transition",//70
            "HL2_SM1014 Necromancer",//71
            "HL2_FabM Parrot",//72
            "HL1_Bomb",//73
            "CRASH_Set With IDs",//74
            "SeekBar_Set Weapon_1_100",//75
            "SeekBar_Set Skin_1_100000",//76
            "HL1_SET",//77
            "CRASH_Set Gloves",//78
            "HL1_Gloves Phoenix",//79
            "HL1_Gloves Autumn",//80
            "HL1_Gloves Geometric",//81
            "HL1_Gloves Retro Wave",//82
            "HL1_Gloves Living Flame",//83
            "HL1_Gloves Neuro",//84
            "HL1_Gloves Burning Fists",//85
            "HL1_Gloves Punk",//86
            "HL1_Gloves Champion",//87
            "HL1_Gloves Steam Rider",//88
            "CRASH_Visuals",//89
            "HL1_Color Chams", //90
            "HL1_Wireframe Chams", //91
            "HL1_Bypass Chams", //92
            "HL1_Glow Chams", //93
            "HL1_Outline Chams", //94
            "HL1_Rainbow Chams", //95
            "Text_Chams Settings",//96
            "SeekBar_Color Red_0_255", //97
            "SeekBar_Color Green_0_255", //98
            "SeekBar_Color Blue_0_255", //99
            "CRASH_Weapons Set",//100
            "HL2_Tanto Knife Dojo",//101
            "HL2_Tanto Knife Mafia",//102
            "HL2_Tanto Knife Malachite",//103
            "HL2_Tanto Knife Pearl Abyss",//104
            "HL2_Tanto Knife Transistor",//105
            "HL2_Tanto Knife Flow",//106
            "HL2_M4A1 BubbleGum",//107
            "HL2_M60 Mecha",//108
            "HL1_GodMode", //109
            "HL1_Radar Hack", //110
            "HL1_Anti-GodMode", //111
            "HL1_Infinity Ammo", //112
            "HL1_Air Jump", //113
            "SeekBar_Set Player Speed_5_35",//114
            "HL1_Fire Rate", //115
            "HL1_Fast Plant", //116
            "SeekBar_No Recoil (OFF ~ 25 ~ 50 ~ 75 ~ 100)_0_4",//117
            "HL1_Wallshot", //118
            "HL1_Spoof Name", //119
            "HL1_Unlimited Grenades", //120
            "HL1_Telekill", //121
            "HL1_Masskill", //122
            "HL1_Aimbot", //123
            "HL1_Defuse Anywhere", //124
            "HL1_Auto Defuse", //125
            "HL1_Fast Defuse", //126
            "HL1_Drop Knife", //127
            "HL1_Fast Knife", //128
            "HL1_Plant Anywhere", //129
            "HL1_Move Before Red Timer", //130
            "HL1_Dont Return To Spawn", //131
            "HL1_FastBomb", //132
            "HL1_Radar Hack", //133
            "HL1_Anti Flash", //134
            "HL1_Immunity Grenade", //135
            "SeekBar_Enemy Size_0_100",//136
            "HL1_Spam Chat", //137
            "HL1_No Reload (Lobby)", //138
            "HL1_Nuke Shoots",//139
            "HL1_Respawn Hack", //140
            "HL1_Silent Body",//141
            "HL1_Silent Head", //142
            "HL1_Set Hands Position",//143
            "SeekBar_X_0_150",//144
            "SeekBar_-X_0_150",//145
            "SeekBar_Y_0_150",//146
            "SeekBar_-Y_0_150",//147
            "SeekBar_Z_0_150",//148
            "SeekBar_-Z_0_150",//149
            "HL1_Player Nuke",//150
            "HL1_Enemy Nuke", //151
            "HL1_SpinBot",//152
            "SeekBar_Spin Speed_0_300",///153
            "SeekBar_Jump Height_0_5",//154
            "HL1_Get Medal (Ban)",//155
            "HL2_Teleport To Enemies",//156
            "HL1_Infinity Shop",//157
            "HL1_No Clip",//158
            "HL1_Rainbow Sky",//159
            "HL1_FOV 180°",//160
            "HL1_Bullet Teleport",//161
            "KIRA_Hide Icon",//162
            };

    int Total_Feature = (sizeof features /
                         sizeof features[0]);

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 
