package il2cpp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Toast;
import il2cpp.typefaces.Menu;
import il2cpp.typefaces.Switch;
import il2cpp.typefaces.Slider;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import il2cpp.typefaces.Menu;
import il2cpp.typefaces.AlertInput;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import android.content.Intent;
import android.net.Uri;
import android.content.*; 
import android.content.pm.*; 
import java.io.*; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException; 
import java.util.*; 

import android.os.*; 
import android.util.Base64;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import il2cpp.Main;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;

//private String assetSavePath = "";
public class Main 
{
	protected static Context context;
	protected LinearLayout childOfScroll;
	
	public static native void Changes(int feature, int value);

    private static native String[] getFeatures();
	
	public static boolean hide;
    
    private static native String icok();
    public static native String apk();

	public static void start(final Context context) {
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					System.loadLibrary("ENGINEER");
					try {
						new Main().MenuMain(context);
					} catch(Exception e) {
						Toast.makeText(context, "Modded by Engineer mods", Toast.LENGTH_LONG).show();
					}
				}
			}, 3000);
	}
    
	public final void MenuMain(final Context context)
	{
        try {
		Main.context = context;
		Menu menu=new Menu(context);
		menu.setIconImage(icok());
		menu.showMenu();
		String[] listFT = getFeatures();  
		for (int i = 0; i < listFT.length; i++) {
			final String[] split = listFT[i].split("_");
			if (split[0].equals("page")) {
				menu.addPage(split[1]);
			} else if (split[0].equals("switch")) {
				menu.newCheck(Integer.parseInt(split[1]), split[3], new OnClickListener() {
					public void onClick(View v){
						Changes(Integer.parseInt(split[2]), 0);
					}
				});
			} else if (split[0].equals("slider")) {
				menu.newSlider(Integer.parseInt(split[1]), split[3], Integer.parseInt(split[4]), Integer.parseInt(split[5]), new Slider.Callback() {
					public void onChange(int v){
						Changes(Integer.parseInt(split[2]), v);
					}
				});
			}
		}
		
		} catch (Exception e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
    }
}

