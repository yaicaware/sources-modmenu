package il2cpp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Process;
import android.os.StrictMode;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import android.text.Html;
import javax.net.ssl.HttpsURLConnection;

/*import okhttp3.FormBody;
 import okhttp3.OkHttpClient;
 import okhttp3.Request;
 import okhttp3.RequestBody;
 import okhttp3.Response;*/

public class TOKEN extends Activity {

    public static native void Check();
	//private static String strpass;

	private static String strUser;



	protected static native void TOKEN(Context VVVVSJSBSNS);

	protected static native void DDDDD(Context TTTTTT);


	public static String getUserToken(Context context) {
		final SharedPreferences sharedPreferences = context.getSharedPreferences("SavePref", 0);
        strUser = sharedPreferences.getString("Enter token", null);


		// Log.d("test228", strUser);
        return strUser;


	}
    public static void Start(final Context context) {
        //Load lib file
        System.loadLibrary("ENGINEER");
		il2cpp.Main.start(context);
		//il2cpp.StaticActivity.Start(context);

        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Create shared preferences to remember user and pass
            final SharedPreferences sharedPreferences = context.getSharedPreferences("SavePref", 0);
            String struser = sharedPreferences.getString("Enter token", null);
            Boolean rememberMe = sharedPreferences.getBoolean("RememberMe", false);

            //Create LinearLayout
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setBackgroundColor(Color.parseColor("#ffffff"));
            linearLayout.setPadding(4, 4, 4, 4);

            //Create username edittext field
            EditText editTextUser = new EditText(context);
            if (struser != null && !struser.isEmpty()) {
                editTextUser.setText(struser);
            }
            editTextUser.setHintTextColor(Color.parseColor("#444444"));
            editTextUser.setTextColor(Color.parseColor("#000000"));
            editTextUser.setHint("Введите токен");

            //Create checkbox
            CheckBox checkSaveLogin = new CheckBox(context);
            checkSaveLogin.setPadding(0, 5, 0, 5);
            checkSaveLogin.setTextSize(18);
            checkSaveLogin.setChecked(rememberMe);
            checkSaveLogin.setTextColor(Color.parseColor("#000000"));
            checkSaveLogin.setText("Запомнить меня");

            //Create btnLogin
            final Button btnLogin = new Button(context);
            btnLogin.setBackgroundColor(Color.parseColor("#ffffff"));
            btnLogin.setTextColor(Color.parseColor("#000000"));
            btnLogin.setText("Готово");

            //Create btnSair


            //Create username textView


            //Add views
            linearLayout.addView(editTextUser);
            linearLayout.addView(btnLogin);



            //Create alertdialog
            AlertDialog.Builder builder = new AlertDialog.Builder(context);

            //Title


            builder.setCancelable(false);
            builder.setView(linearLayout);
            AlertDialog show = builder.show();

            final EditText editText3 = editTextUser;

            final CheckBox checkSaveLogin2 = checkSaveLogin;
            final AlertDialog alertDialog = show;



            btnLogin.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View view, MotionEvent motionEvent) {
						if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
							// textStatus.setTextColor(Color.parseColor("#ffffff"));
							//  textStatus.setText("logging in...");
							// btnLogin.setBackgroundColor(Color.parseColor("#37bb83"));
						} else if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
							//   btnLogin.setBackgroundColor(Color.parseColor("#299164"));
						}
						return false;
					}
				});

            //Request PHP when pressing login button
            btnLogin.setOnClickListener(new View.OnClickListener() {
					public void onClick(View view) {
						String user = editText3.getText().toString().trim();

						boolean isChecked = checkSaveLogin2.isChecked();
						SharedPreferences.Editor edit = sharedPreferences.edit();
						if (!isChecked) {
							edit.putString("Enter token", user);
						} else {
							edit.clear();
						}
						edit.putBoolean("RememberMe", isChecked);
						edit.apply();

						try {
							alertDialog.dismiss();
							Toast.makeText(context, Html.fromHtml(user+""), Toast.LENGTH_LONG).show();

							TOKEN(context);

							//B.management(context);
						} catch (Exception e) {
							//textStatus.setTextColor(Color.rgb(200, 20, 20));
							//textStatus.setText(e.getMessage());
						}


					}
				});


		}
	}
}
      

